# Topaloğlu Pazaryeri Merkezi v10.0.5

## Pazarama
Güncel Pazarama API akışı kullanılır:

- Token: `POST https://isortagimgiris.pazarama.com/connect/token`
- `grant_type=client_credentials`
- `scope=merchantgatewayapi.fullaccess`
- Ürünler: `GET https://isortagimapi.pazarama.com/product/products/approved`

`.env`:

    PAZARAMA_ENABLED=true
    PAZARAMA_API_KEY=...
    PAZARAMA_API_SECRET=...

Eski Pazarama URL / auth override alanlarına gerek yok.

## Tek tek pazaryeri kontrolü
- Üstten pazaryeri seç → **Seçileni Kontrol Et**
- Her pazaryeri kartında yalnız o pazaryerini kontrol etme butonu
- **Tümünü Kontrol Et** bütün aktif pazaryerlerini çalıştırır

## Devam eden özellikler
- 500 TL alarm toleransı
- T-Soft BuyingPrice üzerinden zarar kontrolü
- Manuel eşleştirme
- Idefix ana SKU / varyant desteği
- Risk odaklı premium dashboard


## v8.1 düzeltmesi

Pazarama token servisi başarılı cevabı şu yapıda döndürebiliyor:

    {
      "success": true,
      "data": {
        "accessToken": "...",
        "expiresIn": 3600,
        "tokenType": "Bearer"
      }
    }

v8.1 artık hem üst seviye `access_token/accessToken` hem de `data.accessToken` yapısını destekler.
Ayrıca token alma hatasında access token'ın tamamını loga yazdırmaz.


## v8.2 — Pazarama cursor sayfalama düzeltmesi

Pazarama'nın Temmuz 2026 güncellemesine göre:

- `Page` parametresi kaldırıldı.
- Sayfalama `Cursor` ile yapılır.
- Tek istekte maksimum `Size=100` kullanılabilir.

v8.2 artık:

    GET /product/products/approved?Size=100

ile başlar. Cevaptaki cursor değeri varsa sonraki istekte:

    GET /product/products/approved?Size=100&Cursor=...

şeklinde devam eder.

Ayrıca 400 hatasında Pazarama'nın döndürdüğü gerçek hata mesajı panelde gösterilir.


## v8.3 — Akıllı 5 adaylı manuel eşleştirme

Manuel Eşleştirme ekranında bir T-Soft ürünü seçildiğinde sistem pazaryeri kataloğunu tarar ve en yakın 5 ürünü otomatik gösterir.

Skorlamada şunlar kullanılır:

- Tam barkod eşleşmesi
- Tam SKU eşleşmesi
- Ana SKU eşleşmesi (`TP1218-17` -> `TP1218`)
- Ürün adı benzerliği
- Ortak kelime oranı
- SKU / barkod / main-id içinde kod benzerliği

Bu özellik özellikle **Idefix** ve **Pazarama** için tasarlanmıştır.

Doğru üründe **Bunu Eşleştir** butonuna basıldığında mapping kalıcı olarak SQLite veritabanına kaydedilir ve sonraki kontrollerde `MANUEL` eşleşme olarak kullanılır.


## v8.4 — Tek tıkla başlatma

Artık PowerShell komutlarını elle yazmanız gerekmez.

### Normal kullanım

1. Önceki sürümdeki `.env` dosyasını v8.4 klasörüne kopyalayın.
2. `BASLAT.bat` dosyasına çift tıklayın.

İlk çalıştırmada otomatik olarak:
- `.venv` oluşturulur,
- `requirements.txt` paketleri yüklenir,
- tarayıcı açılır,
- FastAPI/Uvicorn başlatılır.

Sonraki çalıştırmalarda paketler değişmediyse kurulum tekrarlanmaz.

### Masaüstünden çalıştırmak

Bir kez:

    MASAUSTU_KISAYOL_OLUSTUR.bat

dosyasına çift tıklayın.

Masaüstüne **Topaloglu Fiyat Koruma** kısayolu gelir. Bundan sonra yalnız bu kısayola çift tıklamanız yeterlidir.

### Sessiz/minimize başlatma

`BASLAT_SESSIZ.vbs` dosyası terminal penceresini minimize ederek başlatır.

### Gereksinim

Bilgisayarda Python kurulu olmalıdır. Python yoksa başlatıcı açıklayıcı hata verir.


## v8.5 — Eşleştirme sadeleştirildi

Yeni öncelik sırası:

1. **T-Soft ProductCode / SupplierProductCode ↔ pazaryeri ürün/market kodu birebir**
2. **Varyant ana kodu:** `TP1218-17`, `TP1218-15`, `TP1218-STD` → `TP1218`
3. **Barkod birebir**
4. **Ürün adı birebir**
5. SKU / Main ID
6. Tekil benzer SKU
7. Son çare manuel eşleştirme

Pazaryeri kodu artık yalnız `stock_code` alanında değil;
`stock_code`, `product_main_id` ve `barcode` alanlarının tamamında T-Soft TP koduna karşı kontrol edilir.

Aynı ana ürün kodunda birden fazla varyant bulunursa güvenlik amacıyla
**0 TL olmayan en düşük satış fiyatlı varyant** kontrol edilir.

Ürün isimleri birebir aynıysa artık manuel eşleştirme gerekmeden
`ÜRÜN ADI BİREBİR` yöntemiyle otomatik eşleşir.


## v8.6 — API Teşhis ekranı

Idefix ve Pazarama'da isimler panelde birebir aynı olmasına rağmen otomatik eşleşme oluşmuyorsa,
sorunun kaynağı pazaryeri API'sindeki gerçek alan adını yanlış okumamız olabilir.

Sol menüden **API Teşhis** açın:

1. Idefix veya Pazarama seçin.
2. **İlk 5 Kaydı Göster** butonuna basın.
3. Gelen ham JSON kaydında `TP...` kodunun ve ürün adının hangi alanlarda bulunduğunu görün.

Token, secret ve benzeri hassas alanlar ekranda maskelenir.


## v8.6.1 — API Teşhis düzeltmesi

Pazarama ana kontrolü ürünleri çekerken API Teşhis ekranının boş kalması düzeltildi.

- Debug çağrısı artık `Size=100` kullanır ve ilk 5 kaydı gösterir.
- Ham API yine boş dönerse ana kontrolde SQLite'a kaydedilmiş `marketplace_catalog`
  kayıtlarından ilk 5 ürün gösterilir.
- Ekranda kaynağın `Ham API` veya `Kayıtlı katalog` olduğu belirtilir.


## v8.7 — Doğrudan ürün adı eşleştirmesi

Bu sürümde İdefix ve Pazarama JSON cevaplarında ürün adı/kodu yalnız üst seviyede aranmaz.
Alan hangi iç içe seviyede olursa olsun `deep_pick()` ile bulunur.

Öncelik:

1. TP / ürün kodu
2. Normalize edilmiş ürün adı birebir
3. Barkod
4. SKU / Main ID
5. Benzer SKU
6. Manuel

Örnek:

    T-Soft: 14 Ayar Altın Kalemli Ajda Bilezik
    Pazarama: 14 Ayar Altın Kalemli Ajda Bilezik

normalize sonrası aynıysa otomatik olarak `ÜRÜN ADI BİREBİR` eşleşir.

Pazaryeri kartlarında artık **İsim okunan** sayısı da görünür. 
Bu sayı, API'den kaç ürün adını gerçekten çekebildiğimizi gösterir.


## v8.9 — Gerçek ürün adı kaynakları

- Idefix artık `pim/pool/{vendorId}/list` kullanır; `title`, `vendorStockCode`, `productMainId`, `price`, `inventoryQuantity` alınır.
- Pazarama `product/getProducts` metadata servisi ile `Name`, `DisplayName`, `Code`, `GroupCode` alır.
- Pazarama metadata, `product/products/approved` fiyat/stok akışıyla barkod/Code üzerinden birleştirilir.
- Böylece `İsim okunan` sayısı sıfır kalmamalı ve T-Soft ürün adıyla birebir eşleştirme gerçekten çalışmalıdır.


## v8.9 — Idefix güncel fiyat + doğru varyant
- Idefix `pool/list`: ürün adı / vendorStockCode / productMainId metadata.
- Idefix `inventory/list`: güncel fiyat ve stok.
- İki kaynak yalnız barkodla birleştirilir.
- Aynı ana TP veya aynı isimde birden fazla varyant varsa artık en ucuz fiyat seçilmez.
- Belirsiz varyantlarda T-Soft satış fiyatı + komisyona göre beklenen pazaryeri fiyatına en yakın kayıt seçilir.


## v8.10 — Pazarama aktif varyant düzeltmesi

- `TP1148-18,5` gibi ondalıklı/virgüllü varyant kodları artık `TP1148` ana SKU'suna doğru indirgenir.
- Pazarama'da stok `0` olan veya API tarafından açıkça pasif gösterilen kayıtlar eşleştirmeye alınmaz.
- Approved feed ile metadata birleşirken önce **aynı varyant kodu**, sonra barkod kullanılır.
- Aynı `GroupCode` altındaki farklı varyantlar artık yanlışlıkla birbirine bağlanmaz.
- Approved ile birleşmeyen metadata kayıtları yalnız gerçekten stoklu + fiyatlı + aktif ise kataloğa eklenir.
- Aynı isimli birden fazla varyant varsa T-Soft TP ailesi önceliklendirilir; başka TP kodlu ürünün fiyatı kullanılmaz.

Örnek:
`TP1148` yalnız `TP1148-18,5` ailesiyle eşleşir; `TP1264-19` veya `TP1150-18,5` fiyatı kullanılamaz.


## v8.11 — Pazarama komisyon düzeltmesi

- 14 Ayar Takılar: %22
- 8 Ayar Takılar: %22
- Diğer Pazarama grupları mevcut oranlarında bırakıldı.


## v8.12 — Stok 0 ve satışa kapalı ürün kontrolü

- STOK YOK: pazaryeri stok değeri 0 veya altı.
- SATIŞA KAPALI: API kaydı açıkça pasif/kapalı gösteriyor.
- AKTİF: stok var ve satış açık.
- Bu kayıtlar LOSS zarar alarmına karışmaz.
- Pazaryeri kartlarında Stok 0 ve Kapalı sayıları gösterilir.
- Risk listesine satış durumu filtresi eklendi.


## v8.13 — Trendyol row hatası düzeltmesi

`availability_status(row)` çağrısı artık yalnız eşleşmiş bir pazaryeri satırı varsa çalışır.
Eşleşmemiş / row oluşmamış akışlarda `BİLİNMİYOR` kabul edilir ve uygulama hata vermez.


## v8.14 — Fiyat riski / stok durumu ayrımı + premium panel

### Kritik mantık değişikliği
- Stok `0` olan pazaryeri ürünü artık `LOSS / CRITICAL / WARNING` olamaz.
- API açıkça satışa kapalı/pasif diyorsa fiyat hesabı yapılmaz.
- Bu kayıtlar **Fiyat Riskleri** tablosundan tamamen çıkarılır.
- Ayrı **Stok & Yayın Durumu** bölümünde `STOK YOK` ve `SATIŞA KAPALI` olarak gösterilir.

### Yeni premium arayüz
- Yönetici KPI alanı ve sağlık skoru.
- Zarar, sapma, stok 0 ve kapalı durumları ayrı kartlarda.
- Pazaryeri bazlı sağlık kartları.
- Fiyat güvenliği ile operasyon kontrolü ayrı tablolar.
- Daha kompakt ve okunabilir premium koyu arayüz.


## v8.15 — Windows masaüstü fiyat alarmı

- APScheduler'ın mevcut 5 dakikalık kontrol turu tamamlandığında fiyat riskleri incelenir.
- `LOSS`, `CRITICAL` veya `WARNING` varsa Windows sağ alt köşede masaüstü bildirimi gösterilir.
- `STOK YOK` ve `SATIŞA KAPALI` kayıtlar masaüstü fiyat alarmına dahil edilmez.
- Aynı risk listesi değişmeden devam ediyorsa her 5 dakikada bir tekrar bildirim gönderilmez.
- Yeni ürün riske girerse, fiyat/risk durumu değişirse veya risk temizlenip tekrar oluşursa yeni bildirim gelir.
- Riskler tamamen temizlendiğinde "Fiyat riskleri temizlendi" bildirimi gelir.
- Üst menüde `Bildirimi Test Et` butonu bulunur.
- Windows masaüstü bildirimleri için `winotify` bağımlılığı eklendi. `BASLAT.bat` requirements değişikliğini algılayıp otomatik kurar.


## v8.16 — Tek ürün kontrolü + kalıcı manuel eşleştirme

- Sol menüde Tek Ürün Kontrol ekranı eklendi.
- TP kodu ile yalnız tek ürün tüm aktif pazaryerlerinde sorgulanır.
- Manuel eşleştirmeye Barkod/SKU/Main ID alanı ve Eşleştirmeyi Kaydet butonu eklendi.
- Manuel kayıt SQLite manual_mappings tablosuna yazılır ve yenilemede kaybolmaz.


## v8.17 — Masaüstü bildirim DB hatası düzeltmesi

`db.checks()` isim hatası düzeltildi.
Bildirim sistemi ve tek ürün kontrolü artık veritabanındaki gerçek kontrol listesi fonksiyonunu (`list_checks`) kullanır.
Ek olarak geriye dönük uyumluluk için `db.checks()` alias'ı eklendi.


## v8.18 — Türkçe durumlar + premium animasyonlar

Ekranda teknik statüler artık Türkçe gösterilir:
- LOSS → Zarar
- CRITICAL → Kritik
- WARNING → Uyarı
- OK → Normal
- UNRESOLVED → Eşleşmedi
- REVIEW → İncelenecek
- IGNORED → Dikkate Alınmadı
- STOK YOK → Stok Yok
- SATIŞA KAPALI → Satışa Kapalı

Veritabanındaki teknik durum kodları değiştirilmez; yalnız kullanıcı arayüzü Türkçeleştirilir.

Yeni hareket sistemi:
- Sayfa geçişlerinde fade + slide.
- KPI sayılarında animasyonlu artış/azalış.
- Kartlarda premium hover/yükselme.
- Tablo satırlarında sıralı giriş animasyonu.
- Durum rozetlerinde yumuşak pop animasyonu.
- Butonlarda daha doğal basma/hover geçişleri.
- Hareket azaltma sistem tercihine uyumluluk.


## v8.19
- Fiyat tablosundan Eşleşme ve Alış sütunları kaldırıldı.
- Pazaryeri kartlarına Fiyatı Tutan sayacı eklendi.
- Kartlar Fiyatı Tutan / Fiyat Riski / Stok 0 / Kapalı olarak yeniden düzenlendi.


## v8.20 — Yeni ET barkod yapısı

- Yeni `ET...` barkodları eşleştirme motorunun ana kimliklerinden biri haline getirildi.
- Eski `TP...` ürün kodları geriye dönük uyumluluk için desteklenmeye devam eder.
- T-Soft tarafında Barkod + ProductCode + SupplierProductCode birlikte değerlendirilir.
- Aynı ET barkodu birden fazla üründe kullanılmışsa barkod tek başına kesin eşleşme sayılmaz.
- Tekrarlanan ET barkodlarında birebir ürün adı ile ayrıştırma yapılır.
- Tek ürün kontrolü artık ET barkodu, ürün kodu veya eski TP kodu ile çalışır.
- Aynı ET barkodu birden fazla T-Soft ürününde varsa sistem yanlış ürünü seçmez; daha spesifik ürün kodu ister.
- Manuel eşleştirmedeki `stock_code` ve `product_main_id` alanları gerçek eşleşme indekslerine bağlandı.


## v9.0 — Pazaryeri Operasyon Merkezi
- Yeni ana ekran: aksiyon kuyruğu, potansiyel zarar, ürün kanal matrisi.
- T-Soft + mevcut pazaryeri kontrolleri korunur.
- ConnectProf için güvenli, endpoint uydurmayan adaptör eklendi.
- ConnectProf ürün/dışarı aktarım/sipariş servis path'leri .env üzerinden bağlanır.
- Otomatik ürün kapatma ve fiyat yazma halen KAPALI; yalnız okuma/uyarı güvenli modunda.


## v9.1 — ET barkodları arayüzün ana kimliği

- Risk listesinde SKU sütunu artık `ET Barkod` olarak gösterilir.
- Stok & Yayın listesinde ana kimlik ET barkoddur.
- Ürün Merkezi / Kanal Matrisi ET barkodu öncelikli gösterir.
- Aksiyon Kuyruğu ET barkodu gösterir.
- Ürün Grupları ekranı ET barkodu öncelikli gösterir.
- Eski `TP...` ProductCode silinmez; yalnız ikincil/eski kod olarak küçük şekilde tutulur.
- Eşleştirme ve veritabanı geriye dönük uyumluluk için TP ProductCode'u kullanmaya devam edebilir.


## v9.2 — Hepsiburada ET barkod eşleştirmesi

- `2026ET356835` → `ET356835`
- `2026ET356812` → `ET356812`
- Hepsiburada barkodundaki sayısal prefix temizlenir.
- Normalize edilen ET barkodu T-Soft barkoduyla karşılaştırılır.
- Aynı ET birden fazla üründe varsa birebir ürün adıyla doğrulama yapılır.
- HBCV Merchant SKU ve HB SKU alanları yedek kimlik olarak korunur.


## v9.3 — Hepsiburada API Teşhisi

- `HEPSIBURADA_ENVIRONMENT=prod|sit` desteği eklendi.
- Prod varsayılan listing base URL: `https://listing-external.hepsiburada.com`
- SIT/Test listing base URL: `https://listing-external-sit.hepsiburada.com`
- İstenirse `HEPSIBURADA_LISTING_BASE_URL` ile override edilebilir.
- API Teşhis ekranına Hepsiburada bağlantı kartı eklendi.
- Merchant ID, Username, Password ve User-Agent alanlarının dolu olup olmadığı kontrol edilir.
- 401 / 403 / 404 / 200 durumları Türkçe açıklanır.
- 401 durumunda canlı/test kullanıcı bilgisi uyuşmazlığı ihtimali ayrıca belirtilir.
- User-Agent boşsa uyarı gösterilir.


## v9.4 — Hepsiburada 3 Servis Yetki Teşhisi

Aynı Basic Auth bilgileriyle üç resmi Hepsiburada servis ailesi ayrı ayrı test edilir:

1. Listing / Fiyat-Stok
   - Prod host: `https://listing-external.hepsiburada.com`
   - SIT host: `https://listing-external-sit.hepsiburada.com`

2. Katalog / MPOP
   - Prod host: `https://mpop.hepsiburada.com`
   - SIT host: `https://mpop-sit.hepsiburada.com`
   - Test isteği: `products-by-merchant-and-status`, `productStatus=MATCHED`

3. Sipariş / OMS
   - Prod host: `https://oms-external.hepsiburada.com`
   - SIT host: `https://oms-external-sit.hepsiburada.com`
   - Test isteği: son sipariş listesinden 1 kayıt

Teşhis ekranı her servis için ayrı HTTP kodu ve Auth durumunu gösterir.
Örnek yorum:
- Listing 401 + MPOP 200 + OMS 200 -> genel servis anahtarı hatasından çok Listing yetkisi/endpoint yetkisi sorunu.
- Üçü de 401 -> kullanıcı/servis anahtarı, ortam veya entegratör yetkilendirmesi sorunu.
- 403 -> kimlik kabul edilmiş olsa da Merchant/servis yetkisi yetersiz olabilir.

Bu teşhis hiçbir ürün fiyatı/stoku değiştirmez; salt-okuma GET istekleri kullanır.


## v9.5 — Hepsiburada Teşhis Butonu Düzeltmesi

- `3 Servisi Test Et` butonu artık DOM yüklendikten sonra `addEventListener` ile güvenli biçimde bağlanır.
- Eski kırılgan `onclick` bağlama kaldırıldı.
- Butona basıldığında ekranda anında `Test başlatıldı…` mesajı görünür.
- JavaScript/API hatası oluşursa hata hem panelde hem bildirimde gösterilir.
- Çift event bağlanmasını engellemek için `data-bound` kontrolü eklendi.


## v9.6 — Hepsiburada API'siz Web Okuma Modu

`.env`:
- `HEPSIBURADA_MODE=web`
- `HEPSIBURADA_WEB_SELLER_NAME=Topaloğlu`
- `HEPSIBURADA_WEB_CACHE_MINUTES=30`
- `HEPSIBURADA_WEB_BATCH_SIZE=10`

Web okuma akışı:
1. T-Soft ET barkodunu / ürün adını kullanarak Hepsiburada herkese açık arama sayfası aranır.
2. Aday ürün sayfaları bulunur.
3. Ürün sayfasındaki JSON-LD/meta/embedded sayfa verisinden ürün adı, fiyat, uygunluk, barkod ve satıcı bilgisi okunur.
4. ET barkod + ürün adı ile güvenli eşleşme skoru hesaplanır.
5. Fiyat yalnızca `Topaloğlu` satıcısı doğrulanırsa "trusted_price=true" olur.
6. Satıcı doğrulanmazsa başka satıcının fiyatını bizim fiyatımız sanmamak için zarar alarmı üretilmez.
7. Doğrulanan ürün URL'si çalışma süresince önbelleğe alınır.

Önemli:
- Web okuma API değildir ve Hepsiburada sayfa yapısı değişirse adaptör güncellemesi gerekebilir.
- CAPTCHA/429/403 görülürse uygulama bunu açık hata olarak gösterir; agresif istek yapmaz.
- v9.6 tam 327 ürünü her 5 dakikada crawl etmez. Web okuma tek ürün/kontrollü batch şeklindedir.
- Doğrudan Hepsiburada API modu istenirse `HEPSIBURADA_MODE=api` ile eski connector korunmuştur.


## v9.7 — Hepsiburada Web Modu Ana Kontrole Bağlandı

v9.6'da web okuyucu yalnız API Teşhis / tek web okuma ekranındaydı. Ana `Hepsiburada kontrolü` API connector'a gittiği için web modunda boş sonuç dönüyordu.

v9.7:
- `HEPSIBURADA_MODE=web` iken Hepsiburada kontrol butonu doğrudan web taramasını çalıştırır.
- 5 dakikalık genel kontrol turu da Hepsiburada için web moduna yönlenir.
- Her turda `HEPSIBURADA_WEB_BATCH_SIZE` kadar aktif T-Soft ürünü taranır (varsayılan 10).
- Cursor tutulur; sonraki tur kaldığı yerden devam eder. Böylece 327 ürün aynı anda agresif crawl edilmez.
- Kontrol önceden bulunan Hepsiburada kayıtlarını topluca silmez.
- Topaloğlu satıcısı doğrulanmış fiyat `WEB_TOPALOGLU` yöntemiyle normal risk hesabına girer.
- Ürün bulundu ama satıcı doğrulanamadıysa `REVIEW / İncelenecek` olur ve zarar alarmına dahil edilmez.
- Ürün bulunamazsa yalnız o taranan ürün `UNRESOLVED / Eşleşmedi` olur.
- Tek Ürün Kontrolü de Hepsiburada web modunu doğrudan kullanır.


## v10.0 — Kalıcı Kurulum ve Otomatik Güncelleme

Bu sürümden sonra ZIP/klasör değiştirme dönemi biter.

İlk ve son manuel işlem:
1. Eski `.env` dosyanızı bu paketin köküne koyun.
2. `KUR_VE_MASAUSTUNE_EKLE.bat` dosyasına çift tıklayın.
3. Uygulama `%LOCALAPPDATA%\Topaloglu\PazaryeriMerkezi` altına kurulur.
4. Masaüstüne `Topaloglu Pazaryeri Merkezi` kısayolu oluşturulur.

Güncellemelerde korunur:
- `.env`
- `topaloglu.db`
- `.venv`
- kullanıcı/veri klasörleri

Panel:
- Güncellemeyi Kontrol Et
- Yeni sürüm varsa `vX.Y Güncelle`
- paket SHA256 doğrulaması
- uygulamayı otomatik yeniden başlatma

Güncelleme kaynağı varsayılan:
`topaloglusarraf-afk/topaloglu-updates` public GitHub deposu.


## 10.0.5 — Hepsiburada Chrome Eklentisi
Normal Chrome oturumunda çalışan Manifest V3 eklentisi ürün/listing tablosundan ET/SKU, ürün adı, fiyat, stok ve durum alanlarını alıp yalnız yerel 127.0.0.1:8080 uygulamasına gönderir. Şifre/cookie/token okunmaz. Duplicate ET rastgele eşleştirilmez. Yazma işlemi yoktur.


## 10.0.5 — Alarm toleransı
- Alarm toleransı 500 TL'den 1.000 TL'ye yükseltildi.
- Eski sabit .env içindeki 500 TL değeri kullanıcı verisini silmeden 1.000 TL'ye taşınır.
- 500 TL dışında özel bir tolerans tanımlıysa korunur.


## 10.0.5 — Ortak ekran
- Ana görünüm sade ortak izleme ekranıdır.
- Kritik fiyat hatasında kırmızı yanıp sönen alarm vardır.
- Yalnız kritik hata, uyarı, izlenen ürün ve aktif sorunlar ana ekranda görünür.
- 30 saniyede bir ekran yenilenir; tam ekran modu eklendi.
