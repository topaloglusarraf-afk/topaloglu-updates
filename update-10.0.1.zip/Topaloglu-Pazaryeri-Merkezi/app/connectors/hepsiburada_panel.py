
from __future__ import annotations
import asyncio, os, re, unicodedata
from pathlib import Path
from playwright.async_api import async_playwright

APP_DIR=Path(__file__).resolve().parents[2]
PROFILE_DIR=APP_DIR/"data"/"hepsiburada-browser-profile"
SELLER_URL=os.getenv("HEPSIBURADA_SELLER_URL","https://merchant.hepsiburada.com/").strip()

_pw=None
_ctx=None
_page=None
_lock=asyncio.Lock()

def _norm(s):
    s=str(s or "").strip().lower().replace("ı","i")
    s=unicodedata.normalize("NFKD",s)
    return "".join(c for c in s if not unicodedata.combining(c))

async def _ensure():
    global _pw,_ctx,_page
    async with _lock:
        if _ctx:
            try:
                pages=_ctx.pages
                if pages:
                    _page=pages[-1]
                    return _ctx,_page
            except Exception:
                _ctx=None
        PROFILE_DIR.mkdir(parents=True,exist_ok=True)
        _pw=await async_playwright().start()
        try:
            _ctx=await _pw.chromium.launch_persistent_context(
                str(PROFILE_DIR),
                channel="chrome",
                headless=False,
                viewport={"width":1440,"height":900},
                args=["--start-maximized"],
            )
        except Exception as e:
            raise RuntimeError("Google Chrome otomasyonu başlatılamadı. Bilgisayarda Google Chrome kurulu olmalı. Teknik hata: "+str(e))
        pages=_ctx.pages
        _page=pages[-1] if pages else await _ctx.new_page()
        return _ctx,_page

async def open_panel():
    ctx,page=await _ensure()
    try:
        if not page.url or "hepsiburada" not in page.url.lower():
            await page.goto(SELLER_URL,wait_until="domcontentloaded",timeout=45000)
        await page.bring_to_front()
        return {"ok":True,"url":page.url,"message":"Hepsiburada Satıcı Paneli açıldı. Giriş yapıp ürün/listing ekranına gelin."}
    except Exception as e:
        return {"ok":False,"message":str(e)}

async def state():
    try:
        ctx,page=await _ensure()
        body=(await page.locator("body").inner_text(timeout=5000))[:5000]
        nbody=_norm(body)
        login_required=any(w in nbody for w in ["giris yap","sifre","oturum ac","login"])
        return {"ok":True,"url":page.url,"title":await page.title(),"login_required":login_required}
    except Exception as e:
        return {"ok":False,"message":str(e)}

async def _visible_blocks(page):
    return await page.evaluate(r'''() => {
      const clean=s => (s||'').replace(/\s+/g,' ').trim();
      const visible=el=>{const st=getComputedStyle(el),r=el.getBoundingClientRect();return st.display!=='none'&&st.visibility!=='hidden'&&r.width>2&&r.height>2};
      const out=[];
      document.querySelectorAll('table').forEach((t,ti)=>{
        if(!visible(t))return;
        let headers=[...t.querySelectorAll('thead th')].map(x=>clean(x.innerText));
        if(!headers.length){const first=t.querySelector('tr');if(first)headers=[...first.children].map(x=>clean(x.innerText))}
        const rows=[...t.querySelectorAll('tbody tr')].filter(visible).slice(0,100).map(tr=>[...tr.children].map(x=>clean(x.innerText)));
        if(rows.length)out.push({kind:'table',index:ti,headers,rows});
      });
      document.querySelectorAll('[role="grid"],[role="table"]').forEach((g,gi)=>{
        if(!visible(g))return;
        const headers=[...g.querySelectorAll('[role="columnheader"]')].filter(visible).map(x=>clean(x.innerText));
        const rows=[...g.querySelectorAll('[role="row"]')].filter(visible).slice(0,120).map(r=>{
          let cells=[...r.querySelectorAll(':scope > [role="gridcell"], :scope > [role="cell"]')].filter(visible);
          if(!cells.length)cells=[...r.children].filter(visible);
          return cells.map(x=>clean(x.innerText))
        }).filter(r=>r.length>1);
        if(rows.length>1)out.push({kind:'grid',index:gi,headers,rows});
      });
      return out;
    }''')

def _pick(headers, aliases):
    nh=[_norm(h) for h in headers]
    for i,h in enumerate(nh):
        if any(a in h for a in aliases):
            return i
    return None

def _money(s):
    s=str(s or "").replace("₺","").replace("TL","").replace("\xa0"," ").strip()
    m=re.search(r"\d[\d\.\s]*,\d{1,2}|\d[\d,\s]*\.\d{1,2}|\d[\d\.\s]*",s)
    if not m:return None
    raw=m.group(0).replace(" ","")
    if "," in raw:
        raw=raw.replace(".","").replace(",",".")
    elif raw.count(".")>1:
        raw=raw.replace(".","")
    try:return float(raw)
    except:return None

def _stock(s):
    m=re.search(r"-?\d+",str(s or "").replace(".",""))
    return int(m.group(0)) if m else None

def _et(s):
    m=re.search(r"(ET[0-9A-Z._-]+)",str(s or ""),re.I)
    return m.group(1).upper() if m else ""

def _extract(block):
    headers=block.get("headers") or []
    rows=block.get("rows") or []
    hi={
        "price":_pick(headers,["fiyat","satis fiyati","satış fiyatı","price"]),
        "stock":_pick(headers,["stok","stock","adet"]),
        "barcode":_pick(headers,["barkod","barcode"]),
        "sku":_pick(headers,["sku","stok kodu","merchant sku","satici stok kodu","satıcı stok kodu"]),
        "title":_pick(headers,["urun adi","ürün adı","urun","ürün","product"]),
        "status":_pick(headers,["durum","status","yayin","yayın"]),
    }
    score=sum(v is not None for v in hi.values())
    result=[]
    for r in rows:
        def cell(k):
            i=hi[k]
            return r[i] if i is not None and i<len(r) else ""
        joined=" | ".join(r)
        barcode=_et(cell("barcode")) or _et(joined)
        sku=cell("sku")
        price=_money(cell("price")) if hi["price"] is not None else None
        stock=_stock(cell("stock")) if hi["stock"] is not None else None
        title=cell("title") or next((x for x in r if len(x)>12 and not _et(x)), "")
        if barcode or sku or price is not None:
            result.append({"barcode":barcode,"stock_code":sku,"title":title,"price":price,"stock":stock,"status_text":cell("status"),"raw_cells":r})
    return score,result,hi

async def scan_visible():
    ctx,page=await _ensure()
    url=page.url or ""
    if "hepsiburada" not in url.lower():
        return {"ok":False,"code":"WRONG_PAGE","message":"Açık sekme Hepsiburada Satıcı Paneli değil.","url":url}
    blocks=await _visible_blocks(page)
    parsed=[]; diagnostics=[]
    for b in blocks:
        score,rows,hi=_extract(b)
        diagnostics.append({"kind":b.get("kind"),"headers":b.get("headers"),"row_count":len(b.get("rows") or []),"field_map":hi,"score":score})
        if score>=2 and rows:
            parsed.extend(rows)
    seen=set(); unique=[]
    for r in parsed:
        key=(r.get("barcode") or "",r.get("stock_code") or "",r.get("title") or "",r.get("price"))
        if key in seen:continue
        seen.add(key);unique.append(r)
    body=(await page.locator("body").inner_text(timeout=8000))[:8000]
    if any(w in _norm(body) for w in ["giris yap","sifre","oturum ac"]) and not unique:
        return {"ok":False,"code":"LOGIN_REQUIRED","message":"Hepsiburada giriş ekranı görünüyor. Önce giriş yapın.","url":url,"diagnostics":diagnostics}
    if not unique:
        return {"ok":False,"code":"NO_ROWS","message":"Açık sayfada fiyat/stok satırı bulunamadı. Ürün/listing ekranına gelin ve tekrar deneyin.","url":url,"diagnostics":diagnostics,"page_text_sample":body[:1200]}
    return {"ok":True,"url":url,"count":len(unique),"rows":unique[:200],"diagnostics":diagnostics,"message":f"{len(unique)} görünür ürün satırı okundu."}

async def close():
    global _ctx,_pw,_page
    try:
        if _ctx: await _ctx.close()
    except: pass
    try:
        if _pw: await _pw.stop()
    except: pass
    _ctx=_pw=_page=None
    return {"ok":True}
