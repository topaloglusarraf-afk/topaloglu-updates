let D={stats:{},checks:[],products:[],events:[],runtime:{},by_market:{},mappings:[]},H={connections:{}};
let activeMarket='', unresolvedItems=[], selectedUnresolved=null;
const markets=["Trendyol","Hepsiburada","N11","Idefix","Pazarama"];
const $=s=>document.querySelector(s);
const money=n=>n==null?"—":new Intl.NumberFormat("tr-TR",{minimumFractionDigits:2,maximumFractionDigits:2}).format(Number(n))+" TL";


const displayCode=x=>{
  const et=(x?.tsoft_barcode||x?.barcode||'').trim();
  if(et) return et;
  return x?.product_code||'—';
};
const secondaryProductCode=x=>{
  const et=(x?.tsoft_barcode||x?.barcode||'').trim();
  const pc=(x?.product_code||'').trim();
  return et && pc && et!==pc ? pc : '';
};

const statusLabel=s=>({
  'LOSS':'Zarar',
  'CRITICAL':'Kritik',
  'WARNING':'Uyarı',
  'OK':'Normal',
  'UNRESOLVED':'Eşleşmedi',
  'IGNORED':'Dikkate Alınmadı',
  'REVIEW':'İncelenecek',
  'STOK YOK':'Stok Yok',
  'SATIŞA KAPALI':'Satışa Kapalı'
}[s]||s||'—');

function animateNumber(el, target, duration=500){
  if(!el)return;
  const end=Number(target)||0;
  const start=Number(el.dataset.prev||0);
  const t0=performance.now();
  const step=t=>{
    const p=Math.min(1,(t-t0)/duration);
    const eased=1-Math.pow(1-p,3);
    el.textContent=Math.round(start+(end-start)*eased);
    if(p<1) requestAnimationFrame(step);
    else el.dataset.prev=end;
  };
  requestAnimationFrame(step);
}

function animateView(view){
  if(!view)return;
  view.classList.remove('view-enter');
  void view.offsetWidth;
  view.classList.add('view-enter');
}

const toast=m=>{let x=$("#toast");x.textContent=m;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2600)};
async function req(u,o){let r=await fetch(u,o),j=await r.json();if(!r.ok)throw new Error(j.detail||"İstek başarısız");return j}


let OPS={stats:{},actions:[],products:[],runtime:{}};

async function loadOperations(){
  try{
    OPS=await req('/api/operations/overview');
    animateNumber($('#ops-products'),OPS.stats.products||0);
    animateNumber($('#ops-normal'),OPS.stats.normal||0);
    animateNumber($('#ops-risk'),OPS.stats.risks||0);
    animateNumber($('#ops-stock'),OPS.stats.stock_zero||0);
    animateNumber($('#ops-closed'),OPS.stats.closed||0);
    $('#ops-loss').textContent=money(OPS.stats.potential_loss||0);
    renderOpsActions(); renderOpsProducts(); await loadConnectProfHealth();
  }catch(e){toast('Operasyon merkezi: '+e.message)}
}

function renderOpsActions(){
  const market=$('#opsActionMarket')?.value||'', q=($('#opsActionSearch')?.value||'').toLowerCase();
  const rows=(OPS.actions||[]).filter(x=>(!market||x.marketplace===market)&&(!q||JSON.stringify(x).toLowerCase().includes(q)));
  $('#opsActionList').innerHTML=rows.map(x=>`<div class="ops-action ${x.priority==='Çok Yüksek'?'urgent':x.priority==='Yüksek'?'high':''}">
    <div class="ops-priority"><span>${x.priority}</span><small>${x.type}</small></div>
    <div class="ops-action-main"><b>${x.name||'—'}</b><span><code>${x.barcode||x.product_code}</code>${x.barcode&&x.product_code&&x.barcode!==x.product_code?` <em class="legacy-inline">${x.product_code}</em>`:""} · ${x.marketplace} · ${statusLabel(x.status)}</span></div>
    <div class="ops-action-value">${x.net_margin!=null?`<b class="negative">${money(x.net_margin)}</b>`:`<b>${money(x.price)}</b>`}<span>${x.suggestion}</span></div>
  </div>`).join('')||`<div class="ops-empty"><b>Aksiyon gerektiren kayıt yok</b><span>Şu anda problem görünmüyor.</span></div>`;
}

function marketCell(x){
  if(!x)return `<div class="matrix-market missing"><span>—</span><small>Kayıt yok</small></div>`;
  const cls=['LOSS','CRITICAL','WARNING'].includes(x.status)?'risk':x.status==='OK'?'ok':'muted';
  return `<div class="matrix-market ${cls}"><b>${money(x.price)}</b><span>${statusLabel(x.status)}</span><small>Stok ${x.stock??'—'}</small></div>`;
}

function renderOpsProducts(){
  const q=($('#opsProductSearch')?.value||'').toLowerCase();
  const rows=(OPS.products||[]).filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q)).slice(0,250);
  $('#opsProductMatrix').innerHTML=rows.map(x=>`<article class="matrix-row">
    <div class="matrix-product"><code class="primary-code">${x.barcode||x.product_code}</code>${x.barcode&&x.product_code&&x.barcode!==x.product_code?`<small class="legacy-code">Eski kod: ${x.product_code}</small>`:""}<b>${x.name||'—'}</b><span>T-Soft ${money(x.tsoft_price)} · Stok ${x.tsoft_stock??'—'}</span></div>
    ${markets.map(m=>`<div class="matrix-channel"><label>${m}</label>${marketCell((x.markets||{})[m])}</div>`).join('')}
  </article>`).join('')||`<div class="ops-empty"><b>Ürün bulunamadı</b><span>Arama kriterini değiştir.</span></div>`;
}

async function loadConnectProfHealth(){
  try{
    const h=await req('/api/connectprof/health'), box=$('#cpState');
    box.textContent=h.state||'Bilinmiyor'; box.className='cp-state '+(h.ok?'ok':h.configured?'error':'idle');
    $('#cpMessage').textContent=h.message||'';
    $('#cpProductsState').textContent=h.configured?'Hazır':'Bekliyor';
    $('#cpExportsState').textContent=h.configured?'Path bekliyor':'Bekliyor';
    $('#cpOrdersState').textContent=h.configured?'Path bekliyor':'Bekliyor';
  }catch(e){$('#cpState').textContent='Hata';$('#cpState').className='cp-state error';$('#cpMessage').textContent=e.message}
}

async function load(){
  [H,D]=await Promise.all([req('/api/health'),req('/api/dashboard')]);

  $('#tolChip').textContent=money(H.alert_tolerance_tl||500);
  animateNumber($('#s-products'),D.stats.products||0);
  animateNumber($('#s-ok'),D.stats.ok||0);
  animateNumber($('#s-loss2'),D.stats.loss||0);

  const alerts=(D.stats.critical||0)+(D.stats.warning||0);
  animateNumber($('#s-alerts2'),alerts);
  animateNumber($('#s-unresolved'),D.stats.unresolved||0);
  animateNumber($('#s-stock-zero'),D.stats.stock_zero||0);
  animateNumber($('#s-closed'),D.stats.closed||0);

  const priceTotal=(D.stats.price_checked||0);
  const clean=Math.max(0,priceTotal-(D.stats.loss||0)-alerts);
  const score=priceTotal>0?Math.round((clean/priceTotal)*100):100;
  $('#healthScore').textContent=score+'%';

  renderMarkets();
  renderMarketTabs();
  renderChecks();
  renderAvailability();
  renderProducts();
  renderEvents();
}
function renderMarkets(){
  $('#marketStrip').innerHTML=markets.map(n=>{
    const on=!!H.connections[n], s=D.by_market[n]||{}, r=D.runtime||{};
    const last=r['last_'+n+'_success']||'Henüz kontrol edilmedi';
    const risk=(s.loss||0)+(s.critical||0)+(s.warning||0);
    const priceOk=s.ok||0;
    const stock=s.stock_zero||0, closed=s.closed||0;
    const health=(risk===0&&on)?'healthy':risk>0?'attention':'idle';

    return `<article class="market-card glass ${health}">
      <div class="market-top">
        <div>
          <div class="market-title">${n}</div>
          <div class="market-connection"><i class="market-dot ${on?'on':''}"></i>${on?'Bağlı':'Bağlantı bekliyor'}</div>
        </div>
        <span class="market-health ${health}">${health==='healthy'?'Sağlıklı':health==='attention'?'Kontrol gerekli':'Bekliyor'}</span>
      </div>
      <div class="market-last">${last}</div>
      <div class="market-health-grid">
        <div class="market-health-item success"><span>Fiyatı Tutan</span><b>${priceOk}</b><small>Normal fiyat</small></div>
        <div class="market-health-item danger"><span>Fiyat Riski</span><b>${risk}</b><small>Zarar / kritik / uyarı</small></div>
        <div class="market-health-item warning"><span>Stok 0</span><b>${stock}</b><small>Fiyat alarmı dışında</small></div>
        <div class="market-health-item purple"><span>Kapalı</span><b>${closed}</b><small>Satışa kapalı</small></div>
      </div>
      <div class="market-footer">
        <span>Eşleşen ürün <b>${r[n+'_matched']||0}</b></span>
        <button class="market-check-btn" data-check-market="${n}" ${on?'':'disabled'}>${on?'Kontrolü Yenile':'Bağlantı Bekliyor'}</button>
      </div>
    </article>`
  }).join('');
  document.querySelectorAll('[data-check-market]').forEach(b=>b.onclick=()=>checkSingleMarket(b.dataset.checkMarket));
}
function renderMarketTabs(){
  const items=['',...markets];
  $('#marketTabs').innerHTML=items.map(n=>`<button class="market-tab ${activeMarket===n?'active':''}" data-market="${n}">${n||'Tümü'}${n&&D.by_market[n]?` <b>${D.by_market[n].total||0}</b>`:''}</button>`).join('');
  document.querySelectorAll('.market-tab').forEach(b=>b.onclick=()=>{activeMarket=b.dataset.market;renderMarketTabs();renderChecks();renderAvailability()});
}

function renderChecks(){
  const q=$('#search').value.toLowerCase(), sf=$('#statusFilter').value, risk=$('#riskOnly').checked;
  const riskSet=new Set(['LOSS','CRITICAL','WARNING']);
  const excluded=new Set(['STOK YOK','SATIŞA KAPALI']);

  const rows=D.checks.filter(x=>{
    if(excluded.has(x.status))return false;
    if(activeMarket&&x.marketplace!==activeMarket)return false;
    if(sf&&x.status!==sf)return false;
    if(risk&&!riskSet.has(x.status))return false;
    return !q||JSON.stringify(x).toLowerCase().includes(q)
  });

  $('#checksBody').innerHTML=rows.map(x=>{
    const nm=x.net_margin;
    return `<tr class="${x.status}">
      <td><span class="badge">${statusLabel(x.status)}</span></td>
      <td><span class="market-name">${x.marketplace}</span></td>
      <td><code class="primary-code">${displayCode(x)}</code>${secondaryProductCode(x)?`<small class="legacy-code">${secondaryProductCode(x)}</small>`:""}</td>
      <td class="name" title="${x.name||''}">${x.name||''}</td>
      <td><span class="price-main">${money(x.tsoft_price)}</span></td>
      <td>${x.commission_rate==null?'—':'%'+String(x.commission_rate).replace('.',',')}</td>
      <td><span class="price-market">${money(x.current_price)}</span></td>
      <td>${money(x.net_after_commission)}</td>
      <td class="${nm!=null?(nm<0?'negative':'positive'):''}">${money(nm)}</td>
      <td class="${Number(x.difference)<0?'negative-diff':'positive-diff'}">${money(x.difference)}</td>
    </tr>`
  }).join('') || `<tr><td colspan="10"><div class="table-empty"><b>Fiyat riski bulunamadı</b><span>Seçili filtrelerde aksiyon gerektiren ürün görünmüyor.</span></div></td></tr>`;
}
function renderAvailability(){
  const market=$('#availabilityMarket')?.value||'';
  const status=$('#availabilityStatus')?.value||'';
  const q=($('#availabilitySearch')?.value||'').toLowerCase();

  const all=D.checks.filter(x=>x.status==='STOK YOK'||x.status==='SATIŞA KAPALI');
  const rows=all.filter(x=>{
    if(market&&x.marketplace!==market)return false;
    if(status&&x.status!==status)return false;
    return !q||JSON.stringify(x).toLowerCase().includes(q);
  });

  $('#a-total').textContent=all.length;
  $('#a-stock').textContent=all.filter(x=>x.status==='STOK YOK').length;
  $('#a-closed').textContent=all.filter(x=>x.status==='SATIŞA KAPALI').length;

  $('#availabilityBody').innerHTML=rows.map(x=>`
    <tr class="${x.status==='STOK YOK'?'availability-stock':'availability-closed'}">
      <td><span class="availability-badge ${x.status==='STOK YOK'?'stock':'closed'}">${statusLabel(x.status)}</span></td>
      <td>${x.marketplace}</td>
      <td><code class="primary-code">${displayCode(x)}</code>${secondaryProductCode(x)?`<small class="legacy-code">${secondaryProductCode(x)}</small>`:""}</td>
      <td class="name">${x.name||'—'}</td>
      <td><code>${x.marketplace_sku||'—'}</code></td>
      <td>${x.match_method||'—'}</td>
      <td><b>${x.current_stock??0}</b></td>
      <td>${money(x.current_price)}</td>
      <td class="muted-cell">${x.error||'Fiyat alarmı dışında'}</td>
    </tr>
  `).join('') || `<tr><td colspan="9"><div class="table-empty"><b>Operasyon kaydı yok</b><span>Seçili filtrelerde stok 0 veya satışa kapalı ürün bulunmuyor.</span></div></td></tr>`;
}
function renderProducts(){
  const q=$('#productSearch').value.toLowerCase();
  $('#productsBody').innerHTML=D.products.filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q)).slice(0,3000).map(p=>{
    const opts=D.groups.map(g=>`<option ${g===p.price_group?'selected':''}>${g}</option>`).join('');
    return `<tr><td><code class="primary-code">${p.barcode||p.product_code}</code>${p.barcode&&p.product_code&&p.barcode!==p.product_code?`<small class="legacy-code">${p.product_code}</small>`:""}</td><td class="name">${p.name}</td><td>${p.category||'—'}</td><td>${money(p.buying_price)}</td><td>${money(p.selling_price)}</td><td><select class="groupSelect" data-code="${p.product_code}">${opts}</select></td></tr>`
  }).join('');
  document.querySelectorAll('.groupSelect').forEach(s=>s.onchange=async()=>{await req(`/api/products/${encodeURIComponent(s.dataset.code)}/group/${encodeURIComponent(s.value)}`,{method:'POST'});toast('Ürün grubu kaydedildi')});
}

function renderEvents(){
  $('#eventsList').innerHTML=D.events.map(e=>`<div class="event-item"><div class="event-level ${e.level}">${e.level}</div><div class="event-market">${e.marketplace||'Sistem'}${e.product_code?' · '+e.product_code:''}</div><div class="event-message">${e.message}</div><div class="event-time">${e.created_at}</div></div>`).join('');
}


async function runSingleProductCheck(){
  const code=($('#singleProductCode')?.value||'').trim();
  if(!code){toast('Önce ET barkodu veya T-Soft ürün kodunu gir.');return;}
  const btn=$('#singleProductBtn'), old=btn.textContent;
  btn.disabled=true;btn.textContent='Kontrol ediliyor…';
  try{
    const r=await req('/api/check/product/'+encodeURIComponent(code),{method:'POST'});
    const cards=markets.map(m=>{
      const x=(r.markets||{})[m];
      if(!x)return `<article class="single-market-result glass idle"><div class="sm-head"><b>${m}</b><span>Kontrol edilmedi</span></div></article>`;
      const cls=(x.status||'').replaceAll(' ','-').toLowerCase();
      return `<article class="single-market-result glass ${cls}">
        <div class="sm-head"><b>${m}</b><span class="sm-status">${statusLabel(x.status)}</span></div>
        <div class="sm-price">${money(x.current_price)}</div>
        <div class="sm-grid"><div><span>Stok</span><b>${x.current_stock??'—'}</b></div><div><span>Eşleşme</span><b>${x.match_method||'—'}</b></div><div><span>Market SKU</span><b>${x.marketplace_sku||'—'}</b></div><div><span>Net Fark</span><b class="${Number(x.net_margin)<0?'negative':''}">${money(x.net_margin)}</b></div></div>
        <div class="sm-title">${escapeHtml(x.marketplace_title||'')}</div>${x.error?`<div class="sm-error">${escapeHtml(x.error)}</div>`:''}
      </article>`;
    }).join('');
    $('#singleProductResult').innerHTML=`<div class="single-result-head"><div><span>T-SOFT</span><h3>${escapeHtml(r.name||'')}</h3><code>${escapeHtml(r.product_code||code)}</code></div></div><div class="single-market-grid">${cards}</div>`;
    await load();
  }catch(e){
    $('#singleProductResult').innerHTML=`<div class="single-empty glass"><div class="empty-icon">!</div><h3>Kontrol başarısız</h3><p>${escapeHtml(e.message)}</p></div>`;
  }finally{btn.disabled=false;btn.textContent=old;}
}

async function saveDirectManualMapping(){
  if(!selectedUnresolved){toast('Önce soldan bir T-Soft ürünü seç.');return;}
  const match_value=($('#manualMatchValue')?.value||'').trim();
  if(!match_value){toast('Barkod veya SKU değerini gir.');return;}
  const btn=$('#manualSaveBtn'), old=btn.textContent;
  btn.disabled=true;btn.textContent='Kaydediliyor…';
  try{
    await req('/api/mappings/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({
      marketplace:$('#mappingMarket').value,
      product_code:selectedUnresolved.product_code,
      match_key:$('#manualMatchKey').value,
      match_value,
      marketplace_title:($('#manualMatchTitle')?.value||'').trim()
    })});
    $('#manualSaveState').innerHTML=`<span class="save-ok">✓ Kalıcı olarak kaydedildi: ${escapeHtml(match_value)}</span>`;
    toast('Manuel eşleştirme kalıcı olarak kaydedildi.');
    await loadUnresolved(); await load();
  }catch(e){
    $('#manualSaveState').innerHTML=`<span class="save-error">${escapeHtml(e.message)}</span>`;
    toast('Eşleştirme kaydedilemedi.');
  }finally{btn.disabled=false;btn.textContent=old;}
}


async function runHbDiagnostics(){
  const msg0=document.getElementById('hbDiagMessage');
  if(msg0){
    msg0.className='hb-diag-message';
    msg0.innerHTML='<b>Test başlatıldı…</b><span>Hepsiburada servislerine bağlanılıyor.</span>';
  }
  const btn=$('#hbDiagBtn'), old=btn?.textContent||'';
  if(btn){btn.disabled=true;btn.textContent='3 servis test ediliyor…';}
  try{
    const r=await req('/api/hepsiburada/diagnostics');

    const cfg=$('#hbDiagConfig');
    if(cfg) cfg.innerHTML=`
      <div><span>Ortam</span><b>${r.environment||'—'}</b></div>
      <div><span>Merchant ID</span><b>${r.merchant_id_present?'Hazır':'Eksik'}</b></div>
      <div><span>Username</span><b>${r.username_present?'Hazır':'Eksik'}</b></div>
      <div><span>Servis Anahtarı</span><b>${r.password_present?'Hazır':'Eksik'}</b></div>
      <div><span>User-Agent</span><b>${r.user_agent_present?'Hazır':'Eksik'}</b></div>
    `;

    const tests=r.tests||[];
    const icon=t=>{
      const s=t.http_status;
      if(s>=200&&s<300) return '●';
      if(s===401||s===403) return '●';
      return '●';
    };
    const cls=t=>{
      const s=t.http_status;
      if(s>=200&&s<300) return 'ok';
      if(s===401||s===403) return 'bad';
      return 'warn';
    };
    const shortName=t=>{
      if((t.service||'').startsWith('Listing')) return ['LISTING','Fiyat & Stok'];
      if((t.service||'').startsWith('Katalog')) return ['MPOP','Katalog'];
      return ['OMS','Sipariş'];
    };

    const box=$('#hbServiceTests');
    if(box) box.innerHTML=tests.map(t=>{
      const n=shortName(t);
      return `<article class="hb-service-card ${cls(t)}">
        <span>${n[0]}</span>
        <h4>${n[1]}</h4>
        <b>${icon(t)} ${t.state||'—'}</b>
        <em>HTTP ${t.http_status??'—'} · Auth: ${t.auth||'—'}</em>
        <small>${escapeHtml(t.message||'')}</small>
        <code>${escapeHtml(t.url||'')}</code>
      </article>`;
    }).join('');

    const msg=$('#hbDiagMessage');
    if(msg){
      const allOk=tests.length===3&&tests.every(t=>t.http_status>=200&&t.http_status<300);
      msg.className='hb-diag-message '+(allOk?'ok':tests.some(t=>t.http_status===401||t.http_status===403)?'error':'');
      msg.innerHTML=`<b>${r.summary||'—'}</b><span>${escapeHtml(r.message||'')}</span>${r.user_agent_warning?`<small>${escapeHtml(r.user_agent_warning)}</small>`:''}`;
    }
    toast(r.summary||'Hepsiburada teşhisi tamamlandı.');
  }catch(e){
    const msg=$('#hbDiagMessage');
    if(msg){msg.className='hb-diag-message error';msg.innerHTML=`<b>Teşhis Hatası</b><span>${escapeHtml(e.message)}</span>`;}
  }finally{
    if(btn){btn.disabled=false;btn.textContent=old;}
  }
}

async function loadUnresolved(){
  const market=$('#mappingMarket').value;
  const r=await req(`/api/mappings/unresolved?marketplace=${encodeURIComponent(market)}`); unresolvedItems=r.items||[]; renderUnresolved();
}
function renderUnresolved(){
  const q=$('#unresolvedSearch').value.toLowerCase();
  $('#unresolvedList').innerHTML=unresolvedItems.filter(x=>!q||JSON.stringify(x).toLowerCase().includes(q)).map(x=>`<div class="unresolved-item ${selectedUnresolved&&selectedUnresolved.product_code===x.product_code?'active':''}" data-code="${x.product_code}"><b>${x.name}</b><span>${x.product_code} · Barkod: ${x.barcode||'—'} · SKU: ${x.supplier_product_code||'—'}</span></div>`).join('')||'<div class="unresolved-item"><b>Çözülemeyen ürün yok</b><span>Bu pazaryerinde eşleşmeler temiz görünüyor.</span></div>';
  document.querySelectorAll('.unresolved-item[data-code]').forEach(el=>el.onclick=()=>selectUnresolved(el.dataset.code));
}
function selectUnresolved(code){
  selectedUnresolved=unresolvedItems.find(x=>x.product_code===code); if(!selectedUnresolved)return;
  renderUnresolved(); $('#mappingEmpty').classList.add('hidden'); $('#mappingEditor').classList.remove('hidden');
  if($('#manualMatchValue')) $('#manualMatchValue').value=''; if($('#manualMatchTitle')) $('#manualMatchTitle').value=''; if($('#manualSaveState')) $('#manualSaveState').innerHTML='';
  $('#mapProductName').textContent=selectedUnresolved.name; $('#mapProductCode').textContent=selectedUnresolved.product_code; $('#mapProductBarcode').textContent='Barkod: '+(selectedUnresolved.barcode||'—');
  $('#candidateSearch').value=selectedUnresolved.product_code; loadSuggestions(); loadCandidates();
}

async function loadSuggestions(){
  if(!selectedUnresolved)return;
  const market=$('#mappingMarket').value;
  try{
    const r=await req(`/api/mappings/suggestions?marketplace=${encodeURIComponent(market)}&product_code=${encodeURIComponent(selectedUnresolved.product_code)}&limit=5`);
    renderSuggestions(r.items||[]);
  }catch(e){
    $('#suggestionList').innerHTML=`<div class="candidate"><div><div class="title">Öneri alınamadı</div><div class="details">${e.message}</div></div></div>`;
  }
}

function renderSuggestions(items){
  const box=$('#suggestionList');
  if(!box)return;
  if(!items.length){
    box.innerHTML='<div class="candidate"><div><div class="title">Otomatik aday bulunamadı</div><div class="details">Aşağıdaki manuel aramayı kullanabilirsin.</div></div></div>';
    return;
  }

  box.innerHTML=items.map((x,i)=>`
    <div class="suggestion-card">
      <div class="suggestion-rank">${i+1}</div>
      <div class="suggestion-score">Benzerlik ${Math.round(Number(x.candidate_score||0))}</div>
      <div class="stitle">${x.title||x.stock_code||x.barcode||'Pazaryeri ürünü'}</div>
      <div class="smeta">SKU: ${x.stock_code||'—'}<br>Barkod: ${x.barcode||'—'}<br>${money(x.price)}</div>
      <div class="reason">${x.candidate_reason||'Benzer kayıt'}</div>
      <button
        data-sku="${encodeURIComponent(x.stock_code||'')}"
        data-barcode="${encodeURIComponent(x.barcode||'')}"
        data-pmid="${encodeURIComponent(x.product_main_id||'')}"
        data-title="${encodeURIComponent(x.title||'')}"
      >Bunu Eşleştir</button>
    </div>
  `).join('');

  box.querySelectorAll('button').forEach(b=>b.onclick=()=>saveCandidate(b));
}

async function loadCandidates(){
  if(!selectedUnresolved)return;
  const market=$('#mappingMarket').value, q=$('#candidateSearch').value;
  const r=await req(`/api/mappings/candidates?marketplace=${encodeURIComponent(market)}&q=${encodeURIComponent(q)}&limit=100`); renderCandidates(r.items||[]);
}
function renderCandidates(items){
  $('#candidateList').innerHTML=items.map(x=>`<div class="candidate"><div><div class="title">${x.title||x.stock_code||x.barcode||'Pazaryeri ürünü'}</div><div class="details">SKU: ${x.stock_code||'—'} · Barkod: ${x.barcode||'—'} · Fiyat: ${money(x.price)} · Stok: ${x.stock??'—'}</div></div><button data-id="${x.id}" data-sku="${encodeURIComponent(x.stock_code||'')}" data-barcode="${encodeURIComponent(x.barcode||'')}" data-pmid="${encodeURIComponent(x.product_main_id||'')}" data-title="${encodeURIComponent(x.title||'')}">Eşleştir</button></div>`).join('')||'<div class="candidate"><div><div class="title">Sonuç bulunamadı</div><div class="details">Farklı SKU, barkod veya ürün adıyla arayın.</div></div></div>';
  document.querySelectorAll('.candidate button').forEach(b=>b.onclick=()=>saveCandidate(b));
}
async function saveCandidate(b){
  if(!selectedUnresolved)return; const market=$('#mappingMarket').value;
  const vals={sku:decodeURIComponent(b.dataset.sku),barcode:decodeURIComponent(b.dataset.barcode),pmid:decodeURIComponent(b.dataset.pmid),title:decodeURIComponent(b.dataset.title)};
  let key='sku', value=vals.sku; if(!value&&vals.barcode){key='barcode';value=vals.barcode}else if(!value&&vals.pmid){key='pmid';value=vals.pmid}else if(!value&&vals.title){key='title';value=vals.title}
  await req('/api/mappings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({marketplace:market,product_code:selectedUnresolved.product_code,match_key:key,match_value:value,marketplace_title:vals.title})});
  toast('Manuel eşleştirme kaydedildi. Kontrol yeniden çalıştırılıyor…'); await req('/api/check',{method:'POST'}); selectedUnresolved=null; $('#mappingEditor').classList.add('hidden'); $('#mappingEmpty').classList.remove('hidden'); await load(); await loadUnresolved();
}


async function loadDebug(){
  const market=$('#debugMarket').value;
  try{
    $('#debugContent').innerHTML='<div class="mapping-empty"><div class="empty-icon">⌁</div><h3>API okunuyor…</h3><p>'+market+' ilk kayıtları getiriliyor.</p></div>';
    const r=await req('/api/debug/'+encodeURIComponent(market.toLowerCase()));
    const items=r.items||[];
    const source=r.source==='cached_catalog'?'Kayıtlı katalog':'Ham API';
    $('#debugContent').innerHTML=items.map((x,i)=>`<div class="debug-card"><div class="debug-card-head">${market} · ${source} · Kayıt ${i+1}</div><pre>${escapeHtml(JSON.stringify(x,null,2))}</pre></div>`).join('') || '<div class="mapping-empty"><h3>Kayıt gelmedi</h3><p>Ana Pazarama kontrolünü bir kez çalıştırıp tekrar deneyin.</p></div>';
  }catch(e){
    $('#debugContent').innerHTML=`<div class="mapping-empty"><h3>Teşhis hatası</h3><p>${escapeHtml(e.message)}</p></div>`;
  }
}
function escapeHtml(v){
  return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function checkSingleMarket(name){if(!name)return toast('Önce pazaryeri seç');try{toast(name+' kontrol ediliyor…');await req('/api/check/'+encodeURIComponent(name.toLowerCase()),{method:'POST'});toast(name+' kontrolü tamamlandı');await load();if($('#view-mapping').classList.contains('active'))await loadUnresolved()}catch(e){toast(e.message)}}

document.querySelectorAll('.nav').forEach(b=>b.onclick=async()=>{
async function loadDebug(){
  const market=$('#debugMarket').value;
  try{
    $('#debugContent').innerHTML='<div class="mapping-empty"><div class="empty-icon">⌁</div><h3>API okunuyor…</h3><p>'+market+' ilk kayıtları getiriliyor.</p></div>';
    const r=await req('/api/debug/'+encodeURIComponent(market.toLowerCase()));
    const items=r.items||[];
    const source=r.source==='cached_catalog'?'Kayıtlı katalog':'Ham API';
    $('#debugContent').innerHTML=items.map((x,i)=>`<div class="debug-card"><div class="debug-card-head">${market} · ${source} · Kayıt ${i+1}</div><pre>${escapeHtml(JSON.stringify(x,null,2))}</pre></div>`).join('') || '<div class="mapping-empty"><h3>Kayıt gelmedi</h3><p>Ana Pazarama kontrolünü bir kez çalıştırıp tekrar deneyin.</p></div>';
  }catch(e){
    $('#debugContent').innerHTML=`<div class="mapping-empty"><h3>Teşhis hatası</h3><p>${escapeHtml(e.message)}</p></div>`;
  }
}
function escapeHtml(v){
  return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

async function checkSingleMarket(name){if(!name)return toast('Önce pazaryeri seç');try{toast(name+' kontrol ediliyor…');await req('/api/check/'+encodeURIComponent(name.toLowerCase()),{method:'POST'});toast(name+' kontrolü tamamlandı');await load();if($('#view-mapping').classList.contains('active'))await loadUnresolved()}catch(e){toast(e.message)}}

document.querySelectorAll('.nav').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelectorAll('.view').forEach(x=>x.classList.remove('active'));$('#view-'+b.dataset.view).classList.add('active');if(b.dataset.view==='mapping')await loadUnresolved()});
$('#search').oninput=renderChecks; $('#statusFilter').onchange=renderChecks; $('#riskOnly').onchange=renderChecks; $('#productSearch').oninput=renderProducts; $('#mappingMarket').onchange=()=>{selectedUnresolved=null;$('#mappingEditor').classList.add('hidden');$('#mappingEmpty').classList.remove('hidden');loadUnresolved()}; $('#unresolvedSearch').oninput=renderUnresolved; let timer; $('#candidateSearch').oninput=()=>{clearTimeout(timer);timer=setTimeout(loadCandidates,250)}; $('#refreshSuggestions').onclick=loadSuggestions;
$('#debugBtn').onclick=loadDebug;
$('#singleCheckBtn').onclick=()=>checkSingleMarket($('#singleMarket').value);
$('#syncBtn').onclick=async()=>{try{toast('T-Soft senkronu başladı');let r=await req('/api/sync/tsoft',{method:'POST'});toast(r.count+' ürün güncellendi');await load()}catch(e){toast(e.message)}};
$('#checkBtn').onclick=async()=>{try{toast('Tüm bağlı pazaryerleri kontrol ediliyor');await req('/api/check',{method:'POST'});toast('Kontrol tamamlandı');await load()}catch(e){toast(e.message)}};
load().catch(e=>toast(e.message)); setInterval(()=>load().catch(()=>{}),60000);

if($('#availabilityMarket')) $('#availabilityMarket').onchange=renderAvailability;
if($('#availabilityStatus')) $('#availabilityStatus').onchange=renderAvailability;
if($('#availabilitySearch')) $('#availabilitySearch').oninput=renderAvailability;

if($('#notifyTestBtn')) $('#notifyTestBtn').onclick=async()=>{
  try{
    const b=$('#notifyTestBtn');
    const old=b.textContent;b.disabled=true;b.textContent='Gönderiliyor…';
    const r=await req('/api/notifications/test',{method:'POST'});
    toast(r.message||'Test bildirimi gönderildi.');
    b.textContent=old;b.disabled=false;
  }catch(e){
    toast('Bildirim hatası: '+e.message);
    $('#notifyTestBtn').disabled=false;
    $('#notifyTestBtn').textContent='🔔 Bildirimi Test Et';
  }
};

document.querySelectorAll('.nav').forEach(btn=>{
  btn.addEventListener('click',()=>setTimeout(()=>animateView(document.querySelector('.view.active')),0));
});

if($('#opsRefreshBtn')) $('#opsRefreshBtn').onclick=loadOperations;
if($('#opsCheckAllBtn')) $('#opsCheckAllBtn').onclick=async()=>{document.querySelector('#checkBtn')?.click();setTimeout(loadOperations,1200)};
if($('#opsActionMarket')) $('#opsActionMarket').onchange=renderOpsActions;
if($('#opsActionSearch')) $('#opsActionSearch').oninput=renderOpsActions;
if($('#opsProductSearch')) $('#opsProductSearch').oninput=renderOpsProducts;
if($('#cpTestBtn')) $('#cpTestBtn').onclick=loadConnectProfHealth;
loadOperations();


function bindHepsiburadaDiagnostics(){
  const btn=document.getElementById('hbDiagBtn');
  if(!btn) return;
  // Avoid duplicate handlers when views are re-rendered.
  if(btn.dataset.bound==='1') return;
  btn.dataset.bound='1';
  btn.addEventListener('click', async (ev)=>{
    ev.preventDefault();
    ev.stopPropagation();
    try{
      await runHbDiagnostics();
    }catch(err){
      console.error('Hepsiburada teşhis hatası:',err);
      const msg=document.getElementById('hbDiagMessage');
      if(msg){
        msg.className='hb-diag-message error';
        msg.innerHTML=`<b>Teşhis Hatası</b><span>${escapeHtml(err?.message||String(err))}</span>`;
      }
      toast('Hepsiburada teşhis hatası: '+(err?.message||String(err)));
    }
  });
}

if(document.readyState==='loading'){
  document.addEventListener('DOMContentLoaded',bindHepsiburadaDiagnostics);
}else{
  bindHepsiburadaDiagnostics();
}



async function hbWebDiagnostics(){
  const msg=$('#hbWebState'),btn=$('#hbWebTestBtn');
  if(btn){btn.disabled=true;btn.textContent='Test ediliyor…'}
  if(msg) msg.innerHTML='<b>Web bağlantısı test ediliyor…</b><span>Hepsiburada herkese açık sayfasına bağlanılıyor.</span>';
  try{
    const r=await req('/api/hepsiburada/web/diagnostics');
    if(msg){
      msg.className='hb-diag-message '+(r.ok?'ok':'error');
      msg.innerHTML=`<b>${r.ok?'Web Okuma Hazır':'Web Okuma Başarısız'}</b><span>${escapeHtml(r.message||'')}</span><small>Bulunan ürün linki: ${r.candidate_links??0}</small>`;
    }
  }catch(e){
    if(msg){msg.className='hb-diag-message error';msg.innerHTML=`<b>Web Okuma Hatası</b><span>${escapeHtml(e.message)}</span>`}
  }finally{if(btn){btn.disabled=false;btn.textContent='Web Erişimini Test Et'}}
}

async function hbWebReadProduct(){
  const q=($('#hbWebQuery')?.value||'').trim();
  if(!q){toast('ET barkod veya ürün kodu gir.');return}
  const btn=$('#hbWebReadBtn'),box=$('#hbWebResult');
  if(btn){btn.disabled=true;btn.textContent='Okunuyor…'}
  if(box) box.innerHTML='<div class="ops-empty"><b>Hepsiburada aranıyor…</b><span>Ürün sayfası ve satıcı fiyatı kontrol ediliyor.</span></div>';
  try{
    const r=await req('/api/hepsiburada/web/product/'+encodeURIComponent(q));
    if(r.ambiguous){
      box.innerHTML=`<div class="hb-web-warning"><b>Barkod tekil değil</b><span>${escapeHtml(r.message)}</span>${(r.candidates||[]).map(x=>`<code>${escapeHtml(x.product_code)} · ${escapeHtml(x.name||'')}</code>`).join('')}</div>`;
      return;
    }
    if(!r.ok||!r.matched){
      box.innerHTML=`<div class="hb-web-warning"><b>Güvenilir eşleşme bulunamadı</b><span>${escapeHtml(r.error||'Ürün sayfası doğrulanamadı.')}</span></div>`;
      return;
    }
    const trusted=r.trusted_price;
    box.innerHTML=`<article class="hb-web-product ${trusted?'trusted':'review'}">
      <div><span>ÜRÜN</span><h4>${escapeHtml(r.title||'—')}</h4><code>${escapeHtml(r.tsoft_barcode||r.product_code||'—')}</code></div>
      <div><span>WEB FİYATI</span><strong>${money(r.price||0)}</strong><small>${trusted?'Topaloğlu satıcısı doğrulandı':'Satıcı doğrulanamadı — alarma dahil edilmez'}</small></div>
      <div><span>SATICI</span><b>${escapeHtml(r.seller||'Doğrulanamadı')}</b><small>Eşleşme skoru ${r.score??0}</small></div>
      <div><a href="${escapeHtml(r.url||'#')}" target="_blank" rel="noreferrer">Ürün sayfasını aç ↗</a></div>
    </article>`;
  }catch(e){
    box.innerHTML=`<div class="hb-web-warning"><b>Web okuma hatası</b><span>${escapeHtml(e.message)}</span></div>`;
  }finally{if(btn){btn.disabled=false;btn.textContent="Web'den Ürünü Oku"}}
}

function bindHbWebReader(){
  $('#hbWebTestBtn')?.addEventListener('click',hbWebDiagnostics);
  $('#hbWebReadBtn')?.addEventListener('click',hbWebReadProduct);
  $('#hbWebQuery')?.addEventListener('keydown',e=>{if(e.key==='Enter')hbWebReadProduct()});
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindHbWebReader);else bindHbWebReader();



let UPDATE_STATE=null;
async function checkForUpdate(showToast=true){
  const btn=$('#updateCheckBtn');
  if(btn){btn.disabled=true;btn.textContent='Kontrol ediliyor…'}
  try{
    const r=await req('/api/update/check');
    UPDATE_STATE=r;
    $('#updateVersion').textContent='v'+(r.current||'10.0.0');
    const dot=$('#updateDot'), install=$('#updateInstallBtn');
    if(r.ok&&r.available){
      dot?.classList.add('available');
      if(install){install.classList.remove('hidden');install.textContent='v'+r.latest+' Güncelle'}
      if(btn)btn.textContent='Güncelleme Var';
      if(showToast)toast('Yeni sürüm hazır: v'+r.latest);
    }else{
      dot?.classList.remove('available');
      install?.classList.add('hidden');
      if(btn)btn.textContent=r.ok?'Güncel':'Güncelleme Kanalı Bekleniyor';
      if(showToast)toast(r.message||'Uygulama güncel.');
    }
  }catch(e){
    if(btn)btn.textContent='Tekrar Kontrol Et';
    if(showToast)toast('Güncelleme kontrolü: '+e.message);
  }finally{if(btn)btn.disabled=false}
}
async function installUpdate(){
  const btn=$('#updateInstallBtn');
  if(!UPDATE_STATE?.available){await checkForUpdate(true);if(!UPDATE_STATE?.available)return}
  if(btn){btn.disabled=true;btn.textContent='İndiriliyor…'}
  try{
    const r=await req('/api/update/install',{method:'POST'});
    toast(r.message||'Güncelleme hazırlanıyor…');
    if(btn)btn.textContent='Yeniden başlatılıyor…';
  }catch(e){
    toast('Güncelleme başarısız: '+e.message);
    if(btn){btn.disabled=false;btn.textContent='Tekrar Güncelle'}
  }
}
function bindUpdater(){
  $('#updateCheckBtn')?.addEventListener('click',()=>checkForUpdate(true));
  $('#updateInstallBtn')?.addEventListener('click',installUpdate);
  setTimeout(()=>checkForUpdate(false),2500);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindUpdater);else bindUpdater();



async function hbPanelOpen(){
  const btn=$('#hbPanelOpenBtn'),state=$('#hbPanelState');
  if(btn){btn.disabled=true;btn.textContent='Açılıyor…'}
  if(state)state.innerHTML='<b>Chrome açılıyor…</b><span>Hepsiburada Satıcı Paneli yükleniyor.</span>';
  try{
    const r=await req('/api/hepsiburada/panel/open',{method:'POST'});
    state.className='hb-diag-message '+(r.ok?'ok':'error');
    state.innerHTML=`<b>${r.ok?'Satıcı Paneli Açıldı':'Panel Açılamadı'}</b><span>${escapeHtml(r.message||'')}</span>`;
  }catch(e){
    state.className='hb-diag-message error';
    state.innerHTML=`<b>Panel Açılamadı</b><span>${escapeHtml(e.message)}</span>`;
  }finally{if(btn){btn.disabled=false;btn.textContent='Satıcı Panelini Aç'}}
}
function hbPanelRender(r){
  const box=$('#hbPanelResult'),state=$('#hbPanelState');
  if(!r.ok){
    state.className='hb-diag-message error';
    state.innerHTML=`<b>${r.code==='LOGIN_REQUIRED'?'Giriş Gerekli':'Okuma Tamamlanamadı'}</b><span>${escapeHtml(r.message||'')}</span>`;
    const ds=(r.diagnostics||[]).slice(0,6);
    box.innerHTML=ds.length?`<div class="hb-panel-debug"><b>Bulunan tablo/grid yapıları</b>${ds.map(d=>`<code>${escapeHtml((d.headers||[]).join(' | ')||'(başlık yok)')} · ${d.row_count||0} satır</code>`).join('')}</div>`:'';
    return;
  }
  state.className='hb-diag-message ok';
  state.innerHTML=`<b>${r.count} ürün satırı okundu</b><span>Bu sonuç açık Hepsiburada Satıcı Paneli ekranından geliyor.</span>`;
  box.innerHTML=`<div class="hb-panel-table"><div class="hb-panel-row head"><span>ET / SKU</span><span>Ürün</span><span>Fiyat</span><span>Stok</span></div>${(r.rows||[]).map(x=>`
    <div class="hb-panel-row"><span><b>${escapeHtml(x.barcode||'—')}</b><small>${escapeHtml(x.stock_code||'')}</small></span><span>${escapeHtml(x.title||'—')}</span><span><strong>${x.price!=null?money(x.price):'—'}</strong></span><span>${x.stock!=null?escapeHtml(String(x.stock)):'—'}</span></div>`).join('')}</div>`;
}
async function hbPanelScan(){
  const btn=$('#hbPanelScanBtn'),state=$('#hbPanelState');
  if(btn){btn.disabled=true;btn.textContent='Okunuyor…'}
  if(state)state.innerHTML='<b>Açık Hepsiburada sayfası okunuyor…</b><span>Görünen ürün satırları aranıyor.</span>';
  try{
    const r=await req('/api/hepsiburada/panel/scan',{method:'POST'});
    hbPanelRender(r);
  }catch(e){
    state.className='hb-diag-message error';
    state.innerHTML=`<b>Okuma Hatası</b><span>${escapeHtml(e.message)}</span>`;
  }finally{if(btn){btn.disabled=false;btn.textContent='Açık Sayfayı Oku'}}
}
function bindHbPanel(){
  $('#hbPanelOpenBtn')?.addEventListener('click',hbPanelOpen);
  $('#hbPanelScanBtn')?.addEventListener('click',hbPanelScan);
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindHbPanel);else bindHbPanel();
