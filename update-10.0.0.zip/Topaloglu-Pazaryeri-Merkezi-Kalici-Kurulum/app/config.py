import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

def env_bool(name, default=False):
    return os.getenv(name, str(default)).strip().lower() in {"1","true","yes","on"}

@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "Topaloğlu Fiyat Koruma")
    interval_minutes: int = int(os.getenv("CHECK_INTERVAL_MINUTES", "5"))
    # v6: küçük farkları yoksaymak için ayrı tolerans
    alert_tolerance_tl: float = float(os.getenv("ALERT_TOLERANCE_TL", "500"))
    db_path: str = os.getenv("DB_PATH", "data/topaloglu.db")

    # T-Soft
    tsoft_base_url: str = os.getenv("TSOFT_BASE_URL", "").strip().rstrip("/")
    tsoft_token: str = os.getenv("TSOFT_TOKEN", "").strip()
    tsoft_page_size: int = int(os.getenv("TSOFT_PAGE_SIZE", "200"))

    # Trendyol
    trendyol_enabled: bool = env_bool("TRENDYOL_ENABLED")
    trendyol_seller_id: str = os.getenv("TRENDYOL_SELLER_ID", "").strip()
    trendyol_api_key: str = os.getenv("TRENDYOL_API_KEY", "").strip()
    trendyol_api_secret: str = os.getenv("TRENDYOL_API_SECRET", "").strip()
    trendyol_user_agent: str = os.getenv("TRENDYOL_USER_AGENT", "TopalogluFiyatKoruma/1.0").strip()

    # Hepsiburada
    hepsiburada_enabled: bool = env_bool("HEPSIBURADA_ENABLED")
    hepsiburada_merchant_id: str = os.getenv("HEPSIBURADA_MERCHANT_ID", "").strip()
    hepsiburada_username: str = os.getenv("HEPSIBURADA_USERNAME", "").strip()
    hepsiburada_password: str = os.getenv("HEPSIBURADA_PASSWORD", "").strip()
    hepsiburada_mode: str = os.getenv("HEPSIBURADA_MODE", "web").strip().lower()
    hepsiburada_web_seller_name: str = os.getenv("HEPSIBURADA_WEB_SELLER_NAME", "Topaloğlu").strip()
    hepsiburada_web_batch_size: int = int(os.getenv("HEPSIBURADA_WEB_BATCH_SIZE", "10"))
    hepsiburada_web_cache_minutes: int = int(os.getenv("HEPSIBURADA_WEB_CACHE_MINUTES", "30"))
    hepsiburada_environment: str = os.getenv("HEPSIBURADA_ENVIRONMENT", "prod").strip().lower()
    hepsiburada_listing_base_url: str = os.getenv("HEPSIBURADA_LISTING_BASE_URL", "").strip().rstrip("/")
    hepsiburada_user_agent: str = os.getenv("HEPSIBURADA_USER_AGENT", "").strip()

    # N11
    n11_enabled: bool = env_bool("N11_ENABLED")
    n11_app_key: str = os.getenv("N11_APP_KEY", "").strip()
    n11_app_secret: str = os.getenv("N11_APP_SECRET", "").strip()

    # Idefix
    idefix_enabled: bool = env_bool("IDEFIX_ENABLED")
    idefix_vendor_id: str = os.getenv("IDEFIX_VENDOR_ID", "").strip()
    idefix_api_key: str = os.getenv("IDEFIX_API_KEY", "").strip()
    idefix_api_secret: str = os.getenv("IDEFIX_API_SECRET", "").strip()

    # Pazarama
    pazarama_enabled: bool = env_bool("PAZARAMA_ENABLED")
    pazarama_api_key: str = os.getenv("PAZARAMA_API_KEY", "").strip()
    pazarama_api_secret: str = os.getenv("PAZARAMA_API_SECRET", "").strip()


    # ConnectProf — v9 Operasyon Merkezi
    connectprof_enabled: bool = env_bool("CONNECTPROF_ENABLED")
    connectprof_base_url: str = os.getenv("CONNECTPROF_BASE_URL", "").strip().rstrip("/")
    connectprof_api_key: str = os.getenv("CONNECTPROF_API_KEY", "").strip()
    connectprof_bearer_token: str = os.getenv("CONNECTPROF_BEARER_TOKEN", "").strip()
    connectprof_products_path: str = os.getenv("CONNECTPROF_PRODUCTS_PATH", "").strip()
    connectprof_exports_path: str = os.getenv("CONNECTPROF_EXPORTS_PATH", "").strip()
    connectprof_orders_path: str = os.getenv("CONNECTPROF_ORDERS_PATH", "").strip()

settings = Settings()
