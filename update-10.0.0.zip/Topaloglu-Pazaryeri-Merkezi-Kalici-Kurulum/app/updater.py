from __future__ import annotations
import hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
import httpx

APP_DIR=Path(__file__).resolve().parents[1]
VERSION_FILE=APP_DIR/"VERSION"
DEFAULT_MANIFEST="https://raw.githubusercontent.com/topaloglusarraf-afk/topaloglu-updates/main/latest.json"

def current_version():
    try:return VERSION_FILE.read_text(encoding="utf-8").strip()
    except:return "0.0.0"

def manifest_url():
    return os.getenv("UPDATE_MANIFEST_URL",DEFAULT_MANIFEST).strip() or DEFAULT_MANIFEST

def _vtuple(v):
    nums=[]
    for p in str(v).split("."):
        try: nums.append(int("".join(c for c in p if c.isdigit()) or 0))
        except: nums.append(0)
    return tuple((nums+[0,0,0])[:3])

async def check():
    url=manifest_url()
    try:
        async with httpx.AsyncClient(timeout=15,follow_redirects=True) as client:
            r=await client.get(url,headers={"Cache-Control":"no-cache"})
        if r.status_code==404:
            return {"ok":False,"configured":False,"current":current_version(),"message":"Güncelleme kanalı henüz yayınlanmadı."}
        r.raise_for_status()
        m=r.json()
        latest=str(m.get("version") or "0.0.0")
        return {
            "ok":True,
            "configured":True,
            "current":current_version(),
            "latest":latest,
            "available":_vtuple(latest)>_vtuple(current_version()),
            "notes":m.get("notes") or "",
            "published_at":m.get("published_at") or "",
            "package_url":m.get("package_url"),
            "sha256":m.get("sha256") or "",
            "manifest_url":url,
        }
    except Exception as e:
        return {"ok":False,"configured":True,"current":current_version(),"message":f"Güncelleme kontrolü başarısız: {e}"}

async def prepare_update():
    state=await check()
    if not state.get("ok"):
        return state
    if not state.get("available"):
        return {**state,"message":"Uygulama zaten güncel."}
    package_url=state.get("package_url")
    if not package_url:
        return {**state,"ok":False,"message":"Güncelleme paket adresi manifestte yok."}

    temp_root=Path(tempfile.gettempdir())/"topaloglu_update"
    if temp_root.exists(): shutil.rmtree(temp_root,ignore_errors=True)
    temp_root.mkdir(parents=True,exist_ok=True)
    zip_path=temp_root/"update.zip"

    async with httpx.AsyncClient(timeout=120,follow_redirects=True) as client:
        async with client.stream("GET",package_url) as r:
            r.raise_for_status()
            with open(zip_path,"wb") as f:
                async for chunk in r.aiter_bytes():
                    f.write(chunk)

    expected=(state.get("sha256") or "").lower().strip()
    if expected:
        actual=hashlib.sha256(zip_path.read_bytes()).hexdigest()
        if actual!=expected:
            return {**state,"ok":False,"message":"Güncelleme paketi bütünlük kontrolünden geçmedi (SHA256)."}

    extract=temp_root/"extract"
    extract.mkdir()
    with zipfile.ZipFile(zip_path,"r") as z:
        z.extractall(extract)

    children=[p for p in extract.iterdir()]
    payload=children[0] if len(children)==1 and children[0].is_dir() else extract

    script=temp_root/"apply_update.py"
    script.write_text(r"""
import os, shutil, subprocess, sys, time
from pathlib import Path
app=Path(sys.argv[1])
payload=Path(sys.argv[2])
time.sleep(3)

PRESERVE={'.env','data','topaloglu.db','app.db','.venv','VERSION.backup'}
SKIP={'__pycache__','.git'}

def cp(src,dst):
    if src.name in SKIP:return
    if src.is_dir():
        dst.mkdir(parents=True,exist_ok=True)
        for c in src.iterdir():cp(c,dst/c.name)
    else:
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)

# Preserve user data while updating application files.
for item in payload.iterdir():
    if item.name in PRESERVE:continue
    target=app/item.name
    if target.exists() and item.is_dir() and target.is_dir():
        cp(item,target)
    else:
        if target.exists():
            if target.is_dir():shutil.rmtree(target,ignore_errors=True)
            else:
                try:target.unlink()
                except:pass
        cp(item,target)

# Version file may be updated from payload.
bat=app/'BASLAT.bat'
if bat.exists():
    subprocess.Popen(['cmd','/c',str(bat)],cwd=str(app),creationflags=0x00000008)
""",encoding="utf-8")

    subprocess.Popen(
        [sys.executable,str(script),str(APP_DIR),str(payload)],
        cwd=str(APP_DIR),
        creationflags=(0x00000008 if os.name=="nt" else 0)
    )
    return {**state,"prepared":True,"message":"Güncelleme indirildi. Uygulama kapanıp yeniden açılacak."}
