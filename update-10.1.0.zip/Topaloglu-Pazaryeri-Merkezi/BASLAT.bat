@echo off
rem Topaloglu Kalici Kurulum - .env ve veritabani guncellemelerde korunur
@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title Topaloglu Fiyat Koruma

echo.
echo ============================================================
echo             TOPOGLU FIYAT KORUMA - BASLATIYOR
echo ============================================================
echo.

REM ------------------------------------------------------------
REM 1) Python kontrolu
REM ------------------------------------------------------------
where python >nul 2>nul
if errorlevel 1 (
    echo [HATA] Python bulunamadi.
    echo.
    echo Bilgisayara Python 3.11 veya daha yeni bir surum kurulmasi gerekiyor.
    echo Kurulum sirasinda "Add Python to PATH" secenegi isaretli olmali.
    echo.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM 2) .env kontrolu
REM ------------------------------------------------------------
if not exist ".env" (
    echo [UYARI] .env dosyasi bulunamadi.
    echo.
    echo Onceki surumde kullandigin .env dosyasini bu klasore kopyala.
    echo Ornek dosya: .env.example
    echo.
    pause
    exit /b 1
)

REM ------------------------------------------------------------
REM 3) Sanal ortam yoksa otomatik olustur
REM ------------------------------------------------------------
if not exist ".venv\Scripts\python.exe" (
    echo [1/4] Ilk kurulum: Python sanal ortami olusturuluyor...
    python -m venv .venv
    if errorlevel 1 goto :error
) else (
    echo [1/4] Sanal ortam hazir.
)

REM ------------------------------------------------------------
REM 4) Gereksinimler sadece ilk kez veya requirements degisince
REM ------------------------------------------------------------
set "REQHASH_FILE=.venv\.requirements_hash"
for /f "tokens=*" %%H in ('certutil -hashfile requirements.txt SHA256 ^| findstr /v /i "hash CertUtil"') do set "REQHASH=%%H"
set "OLDHASH="
if exist "%REQHASH_FILE%" set /p OLDHASH=<"%REQHASH_FILE%"

if /i not "!REQHASH!"=="!OLDHASH!" (
    echo [2/4] Gerekli paketler kuruluyor / guncelleniyor...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
    if errorlevel 1 goto :error
    >"%REQHASH_FILE%" echo !REQHASH!
) else (
    echo [2/4] Paketler zaten hazir.
)

REM ------------------------------------------------------------
REM 5) Tarayiciyi uygulama acildiktan sonra ac
REM ------------------------------------------------------------
echo [3/4] Tarayici hazirlaniyor...
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:8080"

REM ------------------------------------------------------------
REM 6) Uygulamayi baslat
REM ------------------------------------------------------------
echo [4/4] Uygulama baslatiliyor...
echo.
echo Uygulama adresi: http://localhost:8080
echo Bu pencere acik kaldigi surece uygulama calisir.
echo Kapatmak icin bu pencereyi kapatabilirsin.
echo.
".venv\Scripts\python.exe" -m uvicorn app.main:app --host 0.0.0.0 --port 8080

if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo ============================================================
echo [HATA] Uygulama baslatilamadi.
echo Yukaridaki hata mesajinin ekran goruntusunu gonderebilirsin.
echo ============================================================
echo.
pause
exit /b 1
