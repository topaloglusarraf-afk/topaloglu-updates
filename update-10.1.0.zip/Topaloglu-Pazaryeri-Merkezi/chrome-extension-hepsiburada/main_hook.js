
(() => {
  if (window.__topalogluNetworkHook) return;
  window.__topalogluNetworkHook = true;

  const interesting = url => {
    const u = String(url || "").toLowerCase();
    if (!u.includes("hepsiburada")) return false;
    return [
      "listing","product","products","inventory","stock","offer","offers",
      "price","merchant","seller","catalog","listing-external","mpop"
    ].some(k => u.includes(k));
  };

  const emit = (url, text, source) => {
    try {
      if (!interesting(url) || !text) return;
      const clipped = String(text).slice(0, 1800000);
      window.dispatchEvent(new CustomEvent("topaloglu-hb-network", {
        detail: { url:String(url||""), source, text:clipped, at:Date.now() }
      }));
    } catch (_) {}
  };

  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const res = await originalFetch.apply(this, args);
    try {
      const url = (args[0] && args[0].url) ? args[0].url : args[0];
      if (interesting(url)) {
        const clone = res.clone();
        clone.text().then(t => emit(url, t, "fetch")).catch(()=>{});
      }
    } catch (_) {}
    return res;
  };

  const XHROpen = XMLHttpRequest.prototype.open;
  const XHRSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this.__topalogluUrl = url;
    return XHROpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function(...args) {
    try {
      this.addEventListener("load", () => {
        try {
          const url = this.__topalogluUrl || this.responseURL || "";
          if (!interesting(url)) return;
          if (this.responseType === "json") emit(url, JSON.stringify(this.response), "xhr-json");
          else if (!this.responseType || this.responseType === "text") emit(url, this.responseText, "xhr-text");
        } catch (_) {}
      });
    } catch (_) {}
    return XHRSend.apply(this, args);
  };
})();
