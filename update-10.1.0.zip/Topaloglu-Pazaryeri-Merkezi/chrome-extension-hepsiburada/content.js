
(() => {
  if (window.__topalogluHbBridgeLoaded) return;
  window.__topalogluHbBridgeLoaded = true;

  const networkPayloads = [];
  const norm = s => String(s || "").replace(/\s+/g, " ").trim();
  const lower = s => norm(s).toLocaleLowerCase("tr-TR");

  const extractET = s => {
    const m = String(s || "").match(/(?:20\d{2})?(ET[0-9A-Z._-]+)/i);
    return m ? m[1].toUpperCase() : "";
  };
  const extractHB = s => {
    const m = String(s || "").match(/HB[A-Z0-9._-]{5,}/i);
    return m ? m[0].toUpperCase() : "";
  };
  const parseMoney = s => {
    const text = String(s || "").replace(/\u00a0/g," ").replace(/₺|TL/gi," ").trim();
    const matches = text.match(/\d[\d.\s]*,\d{1,2}|\d[\d,\s]*\.\d{1,2}|\d[\d.\s]*/g) || [];
    for (const part of matches) {
      let raw = part.replace(/\s/g,"");
      if (raw.includes(",")) raw = raw.replace(/\./g,"").replace(",",".");
      else if ((raw.match(/\./g)||[]).length > 1) raw = raw.replace(/\./g,"");
      const n = Number(raw);
      if (Number.isFinite(n) && n >= 1) return n;
    }
    return null;
  };
  const parseStock = s => {
    const m = String(s || "").replace(/\./g,"").match(/-?\d+/);
    return m ? Number(m[0]) : null;
  };

  window.addEventListener("topaloglu-hb-network", ev => {
    try {
      const d = ev.detail || {};
      if (!d.text) return;
      networkPayloads.push(d);
      if (networkPayloads.length > 30) networkPayloads.shift();
    } catch (_) {}
  });

  function valueByAliases(obj, aliases) {
    if (!obj || typeof obj !== "object") return undefined;
    const entries = Object.entries(obj);
    for (const [k,v] of entries) {
      const nk = lower(k).replace(/[^a-z0-9ğüşöçı]/g,"");
      if (aliases.some(a => nk.includes(a))) return v;
    }
  }

  const PRICE_KEYS = ["price","saleprice","salesprice","sellingprice","merchantprice","amount","fiyat","satisfiyati"];
  const STOCK_KEYS = ["stock","quantity","availablequantity","inventory","adet","stok"];
  const BARCODE_KEYS = ["barcode","barkod","gtin","ean"];
  const SKU_KEYS = ["merchantsku","merchantstockcode","stockcode","sku","satıcıstokkodu","saticistokkodu"];
  const TITLE_KEYS = ["title","name","productname","producttitle","urunadi","ürünadı"];
  const STATUS_KEYS = ["status","state","listingstatus","salestatus","durum"];

  function rowFromObject(obj) {
    if (!obj || typeof obj !== "object" || Array.isArray(obj)) return null;

    const pRaw = valueByAliases(obj, PRICE_KEYS);
    const sRaw = valueByAliases(obj, STOCK_KEYS);
    const bRaw = valueByAliases(obj, BARCODE_KEYS);
    const skuRaw = valueByAliases(obj, SKU_KEYS);
    const tRaw = valueByAliases(obj, TITLE_KEYS);
    const stRaw = valueByAliases(obj, STATUS_KEYS);

    let price = null;
    if (typeof pRaw === "number") price = pRaw;
    else if (pRaw && typeof pRaw === "object") {
      const nested = valueByAliases(pRaw, ["amount","value","price"]);
      price = typeof nested === "number" ? nested : parseMoney(nested);
    } else price = parseMoney(pRaw);

    let stock = null;
    if (typeof sRaw === "number") stock = sRaw;
    else if (sRaw && typeof sRaw === "object") {
      const nested = valueByAliases(sRaw, ["quantity","available","stock","value"]);
      stock = typeof nested === "number" ? nested : parseStock(nested);
    } else stock = parseStock(sRaw);

    const flat = JSON.stringify(obj).slice(0,12000);
    const barcode = extractET(bRaw) || extractET(skuRaw) || extractET(flat);
    const stock_code = norm(skuRaw) || extractHB(flat);
    const title = typeof tRaw === "string" ? norm(tRaw) : "";

    if (price === null) return null;
    if (!barcode && !stock_code && !title) return null;

    return {
      barcode, stock_code, title, price, stock,
      status_text: typeof stRaw === "string" ? norm(stRaw) : "",
      source: "network"
    };
  }

  function walkJson(root, out, depth=0) {
    if (depth > 12 || root == null) return;
    if (Array.isArray(root)) {
      for (const x of root.slice(0,2000)) walkJson(x, out, depth+1);
      return;
    }
    if (typeof root !== "object") return;
    const row = rowFromObject(root);
    if (row) out.push(row);
    const vals = Object.values(root);
    for (const v of vals) {
      if (v && typeof v === "object") walkJson(v, out, depth+1);
    }
  }

  function rowsFromNetwork() {
    const rows = [];
    const diagnostics = [];
    for (const p of networkPayloads) {
      let data = null;
      try { data = JSON.parse(p.text); } catch (_) { continue; }
      const before = rows.length;
      walkJson(data, rows);
      diagnostics.push({url:p.url, source:p.source, extracted:rows.length-before});
    }
    return {rows, diagnostics};
  }

  function rowsFromDom() {
    const candidates = [];
    const selector = "tr,li,div";
    const els = [...document.querySelectorAll(selector)];
    for (const el of els) {
      if (!el.offsetParent) continue;
      const text = norm(el.innerText);
      if (text.length < 10 || text.length > 1800) continue;
      const hasId = /ET[0-9A-Z._-]+/i.test(text) || /HB[A-Z0-9._-]{5,}/i.test(text);
      const hasPrice = /(?:₺|TL|\d[\d.\s]*,\d{2})/i.test(text);
      if (!hasId || !hasPrice) continue;

      // Prefer the smallest visible container that has the useful combination.
      const childUseful = [...el.children].some(ch => {
        const t = norm(ch.innerText);
        return t && t !== text && /ET[0-9A-Z._-]+/i.test(t) && /(?:₺|TL|\d[\d.\s]*,\d{2})/i.test(t);
      });
      if (childUseful) continue;

      const lines = text.split(/\n+/).map(norm).filter(Boolean);
      const barcode = extractET(text);
      const stock_code = extractHB(text) || (lines.find(x => /sku|stok kodu|satıcı stok/i.test(x)) || "");
      const priceLine = lines.find(x => /₺|TL|\d[\d.\s]*,\d{2}/i.test(x)) || text;
      const price = parseMoney(priceLine);
      if (price == null) continue;

      let stock = null;
      const stockLine = lines.find(x => /stok|adet|quantity/i.test(x));
      if (stockLine) stock = parseStock(stockLine.replace(/.*?(stok|adet|quantity)\D*/i,""));

      const title = lines.find(x =>
        x.length > 10 &&
        !/ET[0-9A-Z._-]+/i.test(x) &&
        !/HB[A-Z0-9._-]{5,}/i.test(x) &&
        !/₺|TL|stok|adet|fiyat/i.test(x)
      ) || "";

      candidates.push({barcode, stock_code, title, price, stock, status_text:"", source:"dom"});
    }
    return candidates;
  }

  function dedupe(rows) {
    const seen = new Set(), out = [];
    for (const r of rows) {
      const key = [r.barcode||"", r.stock_code||"", lower(r.title), r.price ?? ""].join("|");
      if (seen.has(key)) continue;
      seen.add(key); out.push(r);
    }
    return out;
  }

  function collect() {
    const net = rowsFromNetwork();
    const dom = rowsFromDom();
    const rows = dedupe([...net.rows, ...dom]);
    return {
      rows,
      diagnostics: {
        network_requests_seen: networkPayloads.length,
        network_sources: net.diagnostics.slice(-12),
        network_rows: net.rows.length,
        dom_rows: dom.length,
        page_url: location.href,
        page_title: document.title
      },
      page_url: location.href,
      page_title: document.title
    };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === "TOPALOGLU_SCAN_PAGE") {
      sendResponse({ok:true, ...collect()});
      return;
    }
  });

  const installBadge = () => {
    if (document.getElementById("topaloglu-hb-extension-badge")) return;
    const badge = document.createElement("div");
    badge.id = "topaloglu-hb-extension-badge";
    badge.textContent = "Topaloğlu Fiyat Köprüsü Aktif";
    Object.assign(badge.style,{
      position:"fixed",right:"12px",bottom:"12px",zIndex:"2147483647",
      background:"#111827",color:"#fff",border:"1px solid rgba(255,255,255,.15)",
      borderRadius:"999px",padding:"7px 10px",font:"11px Arial",opacity:".82",
      pointerEvents:"none"
    });
    (document.body || document.documentElement).appendChild(badge);
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", installBadge, {once:true});
  else installBadge();
})();
