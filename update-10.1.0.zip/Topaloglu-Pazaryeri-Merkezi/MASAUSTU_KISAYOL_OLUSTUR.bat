@echo off
cd /d "%~dp0"
set "APPDIR=%CD%"
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$ws=New-Object -ComObject WScript.Shell; ^
$desktop=[Environment]::GetFolderPath('Desktop'); ^
$s=$ws.CreateShortcut((Join-Path $desktop 'Topaloglu Fiyat Koruma.lnk')); ^
$s.TargetPath=(Join-Path '%APPDIR%' 'BASLAT.bat'); ^
$s.WorkingDirectory='%APPDIR%'; ^
$s.Description='Topaloglu Fiyat Koruma'; ^
$s.Save()"
echo.
echo Masaustune "Topaloglu Fiyat Koruma" kisayolu olusturuldu.
echo Bundan sonra masaustundeki kisayola cift tiklayabilirsin.
echo.
pause
