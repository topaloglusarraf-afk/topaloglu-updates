from __future__ import annotations
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
import httpx
APP_DIR=Path(__file__).resolve().parents[1]
VERSION_FILE=APP_DIR/'VERSION'
CHANNEL='https://raw.githubusercontent.com/topaloglusarraf-afk/topaloglu-updates/main/channel.json'
LEGACY='https://raw.githubusercontent.com/topaloglusarraf-afk/topaloglu-updates/main/latest.json'
PROTECTED={'.env','data','topaloglu.db','app.db','.venv'}
def current_version():
    try:return VERSION_FILE.read_text(encoding='utf-8').strip()
    except:return '0.0.0'
def _v(v):
    a=[]
    for x in str(v).split('.'):
        try:a.append(int(''.join(c for c in x if c.isdigit()) or 0))
        except:a.append(0)
    return tuple((a+[0,0,0])[:3])
def _safe(rel):
    p=Path(str(rel).replace('\\','/'))
    if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('Güvensiz dosya yolu')
    if p.parts[0] in PROTECTED:raise ValueError('Kalıcı kullanıcı verisi güncellenemez')
    return p
async def _json(url):
    async with httpx.AsyncClient(timeout=15,follow_redirects=True) as c:r=await c.get(url,headers={'Cache-Control':'no-cache','Pragma':'no-cache'})
    r.raise_for_status();return r.json()
async def check():
    try:
        m=await _json(CHANNEL);latest=str(m.get('version') or '0.0.0')
        if latest!='0.0.0':return {'ok':True,'configured':True,'channel':'direct','current':current_version(),'latest':latest,'available':_v(latest)>_v(current_version()),'notes':m.get('notes') or '','published_at':m.get('published_at') or '','files':m.get('files') or [],'package_url':m.get('package_url'),'sha256':m.get('sha256') or ''}
    except Exception:pass
    try:
        m=await _json(LEGACY);latest=str(m.get('version') or '0.0.0')
        return {'ok':True,'configured':True,'channel':'legacy','current':current_version(),'latest':latest,'available':_v(latest)>_v(current_version()),'notes':m.get('notes') or '','published_at':m.get('published_at') or '','package_url':m.get('package_url'),'sha256':m.get('sha256') or ''}
    except Exception as e:return {'ok':False,'configured':True,'current':current_version(),'message':f'Güncelleme kontrolü başarısız: {e}'}
async def _download(url,dst,sha=''):
    dst.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256()
    async with httpx.AsyncClient(timeout=120,follow_redirects=True) as c:
        async with c.stream('GET',url,headers={'Cache-Control':'no-cache'}) as r:
            r.raise_for_status()
            with open(dst,'wb') as f:
                async for b in r.aiter_bytes():h.update(b);f.write(b)
    got=h.hexdigest()
    if sha and got.lower()!=str(sha).lower().strip():raise ValueError('SHA256 doğrulaması başarısız')
async def _direct(st):
    files=st.get('files') or []
    if not files:return {**st,'ok':False,'message':'Güncelleme dosya listesi boş.'}
    root=Path(tempfile.gettempdir())/'topaloglu_direct_update';shutil.rmtree(root,ignore_errors=True);stage=root/'stage';stage.mkdir(parents=True)
    rels=[]
    for i in files:
        rel=_safe(i.get('path') or '');url=str(i.get('url') or '')
        if not url.startswith('https://'):raise ValueError('Geçersiz güncelleme adresi')
        await _download(url,stage/rel,i.get('sha256') or '');rels.append(str(rel).replace('\\','/'))
    (root/'manifest.json').write_text(json.dumps({'version':st['latest'],'files':rels},ensure_ascii=False),encoding='utf-8')
    helper=root/'apply.py';helper.write_text("""import json,shutil,subprocess,sys,time\nfrom datetime import datetime\nfrom pathlib import Path\napp=Path(sys.argv[1]);root=Path(sys.argv[2]);stage=root/'stage';time.sleep(3)\nm=json.loads((root/'manifest.json').read_text(encoding='utf-8'));bak=app/'data'/'update-backups'/(datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+m['version']);bak.mkdir(parents=True,exist_ok=True);done=[]\ntry:\n for s in m['files']:\n  r=Path(s);src=stage/r;dst=app/r\n  if dst.exists() and dst.is_file():b=bak/r;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dst,b)\n  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst);done.append(s)\n (app/'VERSION').write_text(m['version'],encoding='utf-8')\nexcept Exception:\n for s in done:\n  r=Path(s);b=bak/r;dst=app/r\n  if b.exists():dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b,dst)\n raise\nbat=app/'BASLAT.bat'\nif bat.exists():subprocess.Popen(['cmd','/c',str(bat)],cwd=str(app),creationflags=0x00000008)\n""",encoding='utf-8')
    subprocess.Popen([sys.executable,str(helper),str(APP_DIR),str(root)],cwd=str(APP_DIR),creationflags=(0x00000008 if os.name=='nt' else 0));return {**st,'prepared':True,'message':f'{len(files)} dosya güncellenecek. Uygulama yeniden başlatılacak.'}
async def _legacy(st):
    root=Path(tempfile.gettempdir())/'topaloglu_update';shutil.rmtree(root,ignore_errors=True);root.mkdir();zp=root/'u.zip';await _download(st['package_url'],zp,st.get('sha256') or '')
    ext=root/'x';ext.mkdir()
    with zipfile.ZipFile(zp) as z:
        base=ext.resolve()
        for i in z.infolist():
            d=(ext/Path(i.filename)).resolve()
            if base not in d.parents and d!=base:raise ValueError('Güvensiz ZIP')
        z.extractall(ext)
    ch=[p for p in ext.iterdir()];payload=ch[0] if len(ch)==1 and ch[0].is_dir() else ext
    helper=root/'apply.py';helper.write_text("""import shutil,subprocess,sys,time\nfrom pathlib import Path\napp=Path(sys.argv[1]);src=Path(sys.argv[2]);time.sleep(3);keep={'.env','data','topaloglu.db','app.db','.venv'}\ndef cp(a,b):\n if a.is_dir():b.mkdir(parents=True,exist_ok=True);[cp(x,b/x.name) for x in a.iterdir() if x.name not in {'__pycache__','.git'}]\n else:b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)\nfor x in src.iterdir():\n if x.name not in keep:cp(x,app/x.name)\nbat=app/'BASLAT.bat'\nif bat.exists():subprocess.Popen(['cmd','/c',str(bat)],cwd=str(app),creationflags=0x00000008)\n""",encoding='utf-8')
    subprocess.Popen([sys.executable,str(helper),str(APP_DIR),str(payload)],cwd=str(APP_DIR),creationflags=(0x00000008 if os.name=='nt' else 0));return {**st,'prepared':True,'message':'Geçiş güncellemesi indirildi. Uygulama yeniden başlatılacak.'}
async def prepare_update():
    st=await check()
    if not st.get('ok'):return st
    if not st.get('available'):return {**st,'message':'Uygulama zaten güncel.'}
    try:return await _direct(st) if st.get('channel')=='direct' and st.get('files') else await _legacy(st)
    except Exception as e:return {**st,'ok':False,'message':f'Güncelleme hazırlanamadı: {e}'}
