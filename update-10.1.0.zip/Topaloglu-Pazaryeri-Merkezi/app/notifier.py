import json
import os
from collections import defaultdict

from . import db

RISK_STATUSES={"LOSS","CRITICAL","WARNING"}


def _runtime_get(key, default=""):
    try:
        return db.runtime_get(key) or default
    except Exception:
        return default


def _runtime_set(key, value):
    try:
        db.runtime_set(key, str(value))
    except Exception:
        pass


def _risk_signature(checks):
    items=[]
    for x in checks:
        if (x.get("status") or "") not in RISK_STATUSES:
            continue
        items.append({
            "marketplace":x.get("marketplace") or "",
            "product_code":x.get("product_code") or "",
            "status":x.get("status") or "",
            "price":round(float(x.get("current_price") or 0),2),
        })
    items.sort(key=lambda x:(x["marketplace"],x["product_code"],x["status"],x["price"]))
    return json.dumps(items,ensure_ascii=False,separators=(",",":"))


def _summary(checks):
    risks=[x for x in checks if (x.get("status") or "") in RISK_STATUSES]
    by_market=defaultdict(int)
    loss=critical=warning=0
    for x in risks:
        by_market[x.get("marketplace") or "Pazaryeri"]+=1
        if x.get("status")=="LOSS": loss+=1
        elif x.get("status")=="CRITICAL": critical+=1
        elif x.get("status")=="WARNING": warning+=1

    markets=" • ".join(f"{k}: {v}" for k,v in sorted(by_market.items()))
    detail=[]
    if loss: detail.append(f"{loss} zarar")
    if critical: detail.append(f"{critical} kritik")
    if warning: detail.append(f"{warning} sapma")
    return risks, ", ".join(detail), markets


def send_price_risk_notification(checks, force=False):
    """
    Windows masaüstü bildirimi.
    Aynı risk seti değişmedikçe tekrar bildirim göndermez.
    """
    risks, detail, markets=_summary(checks)
    signature=_risk_signature(checks)
    previous=_runtime_get("desktop_last_risk_signature","")

    if not risks:
        # Riskler temizlendiğinde imzayı sıfırla; ileride yeniden oluşursa bildirim gelsin.
        if previous:
            _runtime_set("desktop_last_risk_signature","")
            _send_windows(
                "Topaloğlu Fiyat Koruma",
                "Fiyat riskleri temizlendi. Şu anda aktif LOSS / CRITICAL / WARNING kaydı yok."
            )
        return {"sent":False,"count":0,"reason":"no-risk"}

    if not force and signature==previous:
        return {"sent":False,"count":len(risks),"reason":"unchanged"}

    body=f"{len(risks)} üründe fiyat riski: {detail}."
    if markets:
        body += f"\n{markets}"
    body += "\nKontrol merkezini açıp inceleyin."

    ok=_send_windows("Topaloğlu Fiyat Koruma",body)
    if ok:
        _runtime_set("desktop_last_risk_signature",signature)
        _runtime_set("desktop_last_notification_count",len(risks))
    return {"sent":ok,"count":len(risks),"reason":"changed"}


def _send_windows(title, message):
    # Windows dışındaki sistemlerde sessizce geç.
    if os.name!="nt":
        return False
    try:
        from winotify import Notification, audio
        toast=Notification(
            app_id="Topaloğlu Fiyat Koruma",
            title=title,
            msg=message,
            duration="long",
        )
        try:
            toast.set_audio(audio.Default, loop=False)
        except Exception:
            pass
        toast.show()
        return True
    except Exception as e:
        try:
            db.log("ERROR",f"Masaüstü bildirim hatası: {e}")
        except Exception:
            pass
        return False
