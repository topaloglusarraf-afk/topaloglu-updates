import re

SARAF_TERMS = (
    "çeyrek","ceyrek","yarım","yarim","tam altın","tam altin","ata ",
    "cumhuriyet","gremse","reşat","resat","ziynet","hamit"
)

def auto_group(name: str, category: str) -> str:
    text = f"{name or ''} {category or ''}".lower()
    text = re.sub(r"\s+", " ", text)

    # Ayarlı takılar önce kontrol edilir. Böylece
    # "14 Ayar Altın Külçe Kolye Ucu" yanlışlıkla Gram Altın olmaz.
    if "14 ayar" in text or "14ayar" in text:
        return "Takılar-14 Ayar"

    if ("22 ayar" in text or "22ayar" in text) and "bilezik" in text:
        return "22 Ayar Bilezik"

    if any(t in text for t in SARAF_TERMS):
        return "Sarrafiye"

    # Külçe yalnız gerçek gram/külçe yatırım ürünü bağlamında sınıflansın.
    if "gram alt" in text:
        return "Gram Altın"
    if ("külçe" in text or "kulce" in text) and any(k in text for k in ("gram","24 ayar","995","999.9","yatırım","yatirim")):
        return "Gram Altın"

    return "İncelenecek"
