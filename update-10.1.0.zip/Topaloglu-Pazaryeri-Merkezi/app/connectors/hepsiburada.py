from . import hepsiburada_web
import httpx
from ..config import settings

def _base_url():
    # Explicit override wins.
    if getattr(settings,"hepsiburada_listing_base_url",""):
        return settings.hepsiburada_listing_base_url.rstrip("/")
    env=(getattr(settings,"hepsiburada_environment","prod") or "prod").lower()
    if env in {"sit","test","sandbox"}:
        return "https://listing-external-sit.hepsiburada.com"
    return "https://listing-external.hepsiburada.com"

def _auth():
    return (settings.hepsiburada_username,settings.hepsiburada_password)

def _headers():
    h={"Accept":"application/json","Content-Type":"application/json"}
    if settings.hepsiburada_user_agent:
        h["User-Agent"]=settings.hepsiburada_user_agent
    return h

def _configured():
    return bool(
        settings.hepsiburada_enabled and
        settings.hepsiburada_merchant_id and
        settings.hepsiburada_username and
        settings.hepsiburada_password
    )

def _rows_from_payload(j):
    # Listing API payload shapes have varied. Accept common containers.
    if isinstance(j,list):
        return j
    if not isinstance(j,dict):
        return []
    for k in ("listings","content","data","items","results"):
        v=j.get(k)
        if isinstance(v,list):
            return v
        if isinstance(v,dict):
            for kk in ("items","content","listings","data"):
                vv=v.get(kk)
                if isinstance(vv,list):
                    return vv
    return []

def _pick(x,*keys):
    if not isinstance(x,dict): return None
    lower={str(k).lower():v for k,v in x.items()}
    for k in keys:
        if k in x and x[k] not in (None,""):
            return x[k]
        lk=str(k).lower()
        if lk in lower and lower[lk] not in (None,""):
            return lower[lk]
    return None

def _f(v):
    try: return float(v or 0)
    except Exception: return 0.0

def _to_row(x):
    return {
        "barcode":str(_pick(x,"barcode","Barcode") or "").strip(),
        "stock_code":str(_pick(x,"merchantSku","merchantSKU","MerchantSku","sku","stockCode") or "").strip(),
        "product_main_id":str(_pick(x,"hbSku","hbSKU","HepsiburadaSku","productId") or "").strip(),
        "title":str(_pick(x,"productName","title","name","ProductName") or "").strip(),
        "price":_f(_pick(x,"price","salePrice","listingPrice","Price")),
        "stock":_f(_pick(x,"availableStock","stock","quantity","inventoryQuantity")),
        "commission":_f(_pick(x,"commissionRate","commission")),
        "active":None,
    }

async def fetch_all_products():
    if not settings.hepsiburada_enabled:
        return []
    if not _configured():
        raise RuntimeError("Hepsiburada API bilgileri eksik.")

    base=_base_url()
    merchant=settings.hepsiburada_merchant_id
    url=f"{base}/listings/merchantid/{merchant}"

    async with httpx.AsyncClient(timeout=45) as client:
        r=await client.get(url,auth=_auth(),headers=_headers())

    if r.status_code==401:
        raise RuntimeError("Hepsiburada yetkilendirme hatası (401). Kullanıcı/şifre veya test-canlı ortam uyuşmuyor olabilir.")
    if r.status_code==404:
        raise RuntimeError(f"Hepsiburada endpoint bulunamadı (404): {url}")
    r.raise_for_status()

    try:
        j=r.json()
    except Exception:
        raise RuntimeError("Hepsiburada JSON yanıtı okunamadı.")

    rows=[_to_row(x) for x in _rows_from_payload(j)]
    return rows

def _hosts():
    env=(getattr(settings,"hepsiburada_environment","prod") or "prod").lower()
    sit=env in {"sit","test","sandbox"}
    if sit:
        return {
            "environment":"SIT/Test",
            "listing":"https://listing-external-sit.hepsiburada.com",
            "catalog":"https://mpop-sit.hepsiburada.com",
            "orders":"https://oms-external-sit.hepsiburada.com",
        }
    return {
        "environment":"Canlı/Prod",
        "listing":"https://listing-external.hepsiburada.com",
        "catalog":"https://mpop.hepsiburada.com",
        "orders":"https://oms-external.hepsiburada.com",
    }

def _classify_test(name, url, status_code, body=""):
    result={
        "service":name,
        "url":url,
        "http_status":status_code,
        "state":"Bilinmiyor",
        "auth":"Bilinmiyor",
        "message":"",
    }
    if 200 <= status_code < 300:
        result["state"]="Başarılı"
        result["auth"]="Kabul Edildi"
        result["message"]="Servis isteği başarıyla yanıtladı."
    elif status_code==401:
        result["state"]="401 Yetkisiz"
        result["auth"]="Reddedildi"
        result["message"]="Basic Auth reddedildi. Kullanıcı/servis anahtarı veya bu servise ait yetkilendirme kontrol edilmeli."
    elif status_code==403:
        result["state"]="403 Yetki Yok"
        result["auth"]="Kimlik doğrulandı / yetki yetersiz olabilir"
        result["message"]="Bu Merchant veya servis için yetki bulunmuyor olabilir."
    elif status_code==404:
        result["state"]="404 Endpoint"
        result["auth"]="Kesin Değil"
        result["message"]="Endpoint bulunamadı; servis yolu veya ortam kontrol edilmeli."
    elif status_code==400:
        result["state"]="400 İstek"
        result["auth"]="Kesin Değil"
        result["message"]="Sunucu isteği aldı fakat parametre/istek biçimini reddetti. Bu sonuç tek başına kimlik doğrulamayı kanıtlamaz."
    elif 500 <= status_code:
        result["state"]="Sunucu Hatası"
        result["auth"]="Kesin Değil"
        result["message"]=f"Hepsiburada HTTP {status_code} döndürdü."
    else:
        result["state"]=f"HTTP {status_code}"
        result["auth"]="Kesin Değil"
        result["message"]=(body or "")[:240]
    return result

async def _probe(client, name, url, params=None):
    try:
        r=await client.get(url,params=params or {})
        return _classify_test(name,url,r.status_code,r.text)
    except httpx.ConnectError:
        return {"service":name,"url":url,"http_status":None,"state":"Bağlantı Hatası","auth":"Test Edilemedi","message":"Sunucuya bağlantı kurulamadı."}
    except httpx.TimeoutException:
        return {"service":name,"url":url,"http_status":None,"state":"Zaman Aşımı","auth":"Test Edilemedi","message":"Servis zaman aşımına uğradı."}
    except Exception as e:
        return {"service":name,"url":url,"http_status":None,"state":"Hata","auth":"Test Edilemedi","message":str(e)}

async def diagnostics():
    hosts=_hosts()
    merchant=bool(settings.hepsiburada_merchant_id)
    user=bool(settings.hepsiburada_username)
    password=bool(settings.hepsiburada_password)
    ua=bool(settings.hepsiburada_user_agent)

    result={
        "enabled":bool(settings.hepsiburada_enabled),
        "environment":hosts["environment"],
        "merchant_id_present":merchant,
        "username_present":user,
        "password_present":password,
        "user_agent_present":ua,
        "configured":bool(_configured()),
        "tests":[],
        "summary":"Yapılandırma Eksik",
        "message":"",
    }

    if not settings.hepsiburada_enabled:
        result["message"]="HEPSIBURADA_ENABLED=false"
        return result

    if not _configured():
        missing=[]
        if not merchant: missing.append("Merchant ID")
        if not user: missing.append("Username")
        if not password: missing.append("Password")
        result["message"]="Eksik alanlar: "+", ".join(missing)
        return result

    mid=settings.hepsiburada_merchant_id

    # Official service families:
    # Listing: price/stock/listing data
    listing_url=f'{hosts["listing"]}/listings/merchantid/{mid}'
    # Catalog/MPOP: merchant products by status. MATCHED is a documented productStatus value.
    catalog_url=f'{hosts["catalog"]}/product/api/products/products-by-merchant-and-status'
    catalog_params={"merchantId":mid,"productStatus":"MATCHED","version":1,"page":0,"size":1}
    # OMS: paid/open orders. limit is required by current docs.
    orders_url=f'{hosts["orders"]}/orders/merchantid/{mid}'
    orders_params={"offset":0,"limit":1}

    async with httpx.AsyncClient(timeout=30,auth=_auth(),headers=_headers()) as client:
        result["tests"].append(await _probe(client,"Listing / Fiyat-Stok",listing_url,{"offset":0,"limit":1}))
        result["tests"].append(await _probe(client,"Katalog / MPOP",catalog_url,catalog_params))
        result["tests"].append(await _probe(client,"Sipariş / OMS",orders_url,orders_params))

    tests=result["tests"]
    success=sum(1 for t in tests if t["http_status"] is not None and 200 <= t["http_status"] < 300)
    unauthorized=sum(1 for t in tests if t["http_status"]==401)
    forbidden=sum(1 for t in tests if t["http_status"]==403)

    if success==3:
        result["summary"]="Tüm Servisler Başarılı"
        result["message"]="Listing, Katalog ve Sipariş servisleri aynı kimlik bilgilerini kabul etti."
    elif success>0:
        result["summary"]="Kısmi Yetki"
        result["message"]=f"{success}/3 servis başarılı. Sorun genel şifreden ziyade servis/entegrasyon yetkisine özel olabilir."
    elif unauthorized==3:
        result["summary"]="Genel Yetkilendirme Hatası"
        result["message"]="Üç servis de 401 verdi. Kullanıcı/servis anahtarı, ortam veya entegratör yetkilendirmesi kontrol edilmeli."
    elif forbidden:
        result["summary"]="Servis Yetkisi Sorunu"
        result["message"]="En az bir servis 403 verdi. Kimlik bilgileri tanınmış olsa da ilgili servis/Merchant yetkisi eksik olabilir."
    else:
        result["summary"]="Bağlantı Teşhisi Gerekli"
        result["message"]="Servis sonuçlarını ayrı ayrı inceleyin."

    if not ua:
        result["user_agent_warning"]="User-Agent boş. Listing ve OMS servislerinde User-Agent zorunlu olabilir."
    return result

async def fetch_all_listings():
    """
    Full automatic API listing fetch remains available only in api mode.
    Web mode intentionally does not crawl hundreds of public pages every 5 minutes.
    Single/small-batch website verification is exposed through dedicated web endpoints.
    """
    mode=(getattr(settings,"hepsiburada_mode","web") or "web").lower()
    if mode=="web":
        return []
    return await fetch_all_products()
