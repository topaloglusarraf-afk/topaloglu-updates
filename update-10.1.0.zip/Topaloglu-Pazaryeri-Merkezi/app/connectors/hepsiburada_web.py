import json, re, time, unicodedata
from urllib.parse import quote, urljoin
import httpx
from bs4 import BeautifulSoup
from ..config import settings

BASE="https://www.hepsiburada.com"
_HEADERS={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36",
    "Accept-Language":"tr-TR,tr;q=0.9,en;q=0.8",
    "Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
}

_cache={}
_url_map={}

def _norm(s):
    s=str(s or "").strip().lower()
    s=unicodedata.normalize("NFKD",s)
    s="".join(c for c in s if not unicodedata.combining(c))
    s=s.replace("ı","i")
    return re.sub(r"[^a-z0-9]+","",s)

def _et(s):
    m=re.search(r"(ET[0-9A-Z._-]+)",str(s or ""),flags=re.I)
    return m.group(1).upper() if m else ""

def _float(v):
    if v is None:return 0.0
    if isinstance(v,(int,float)):return float(v)
    s=str(v).replace("₺","").replace("TL","").strip()
    # Turkish numeric text
    if "," in s:
        s=s.replace(".","").replace(",",".")
    s=re.sub(r"[^0-9.]","",s)
    try:return float(s)
    except:return 0.0

def _jsonld(soup):
    out=[]
    for tag in soup.find_all("script",attrs={"type":"application/ld+json"}):
        try:
            j=json.loads(tag.string or tag.get_text() or "{}")
            if isinstance(j,list):out.extend(j)
            else:out.append(j)
        except:pass
    return out

def _walk(obj):
    if isinstance(obj,dict):
        yield obj
        for v in obj.values():yield from _walk(v)
    elif isinstance(obj,list):
        for x in obj:yield from _walk(x)

def _parse_product(html,url):
    soup=BeautifulSoup(html,"html.parser")
    title=""
    price=0.0
    availability=""
    seller=""
    barcode=""
    canonical=url

    can=soup.find("link",rel="canonical")
    if can and can.get("href"): canonical=urljoin(BASE,can["href"])

    for j in _jsonld(soup):
        for d in _walk(j):
            typ=d.get("@type")
            types=typ if isinstance(typ,list) else [typ]
            if "Product" in types:
                title=title or str(d.get("name") or "")
                barcode=barcode or str(d.get("gtin13") or d.get("gtin") or d.get("sku") or "")
                offers=d.get("offers")
                seq=offers if isinstance(offers,list) else [offers] if isinstance(offers,dict) else []
                for off in seq:
                    p=_float(off.get("price") or off.get("lowPrice"))
                    if p and not price: price=p
                    availability=availability or str(off.get("availability") or "")
                    sel=off.get("seller")
                    if isinstance(sel,dict): seller=seller or str(sel.get("name") or "")
            if "Offer" in types and not price:
                price=_float(d.get("price") or d.get("lowPrice"))
                sel=d.get("seller")
                if isinstance(sel,dict): seller=seller or str(sel.get("name") or "")

    # Fallbacks from meta
    if not title:
        m=soup.find("meta",property="og:title")
        title=(m.get("content") if m else "") or ""
    if not price:
        for attrs in [
            {"property":"product:price:amount"},
            {"itemprop":"price"},
        ]:
            m=soup.find("meta",attrs=attrs)
            if m:
                price=_float(m.get("content"))
                if price:break

    # Hepsiburada embeds seller/price data in application state. Do conservative scans.
    text=html
    seller_candidates=re.findall(r'"(?:merchantName|sellerName|merchantTitle)"\s*:\s*"([^"]+)"',text,re.I)
    if seller_candidates and not seller:
        target=_norm(settings.hepsiburada_web_seller_name)
        exact=[x for x in seller_candidates if target and target in _norm(x)]
        seller=(exact[0] if exact else seller_candidates[0])

    # Barcode-like ET identifier from page text if present.
    if not _et(barcode):
        em=re.search(r'(?:2026)?(ET[0-9A-Z._-]+)',text,re.I)
        if em: barcode=em.group(1).upper()

    target_seller=_norm(settings.hepsiburada_web_seller_name)
    seller_verified=bool(seller and target_seller and target_seller in _norm(seller))

    return {
        "url":canonical,
        "title":title.strip(),
        "price":price,
        "stock":1 if ("InStock" in availability or price>0) else 0,
        "availability":availability,
        "seller":seller.strip(),
        "seller_verified":seller_verified,
        "barcode":_et(barcode),
    }

def _candidate_links(html):
    soup=BeautifulSoup(html,"html.parser")
    links=[]
    for a in soup.find_all("a",href=True):
        href=a["href"]
        # public product URLs typically contain -p- or product detail paths
        if "-p-" in href or "/p-" in href:
            u=urljoin(BASE,href.split("?")[0])
            if "hepsiburada.com" in u and u not in links:
                links.append(u)
    # HTML escaped/productUrl fallback
    for m in re.finditer(r'https?:\\?/\\?/(?:www\.)?hepsiburada\.com/[^"\\\s]+',html,re.I):
        u=m.group(0).replace("\\/","/")
        if "-p-" in u and u not in links:links.append(u)
    return links[:12]

async def _get(client,url):
    r=await client.get(url,follow_redirects=True)
    if r.status_code in (403,429):
        raise RuntimeError(f"Hepsiburada web erişimi engellendi/limitlendi (HTTP {r.status_code}). Bir süre sonra tekrar deneyin.")
    r.raise_for_status()
    text=r.text
    low=text.lower()
    if "captcha" in low or "robot olmadığınızı" in low or "access denied" in low:
        raise RuntimeError("Hepsiburada web güvenlik doğrulaması istedi. Otomatik web okuma geçici olarak kullanılamıyor.")
    return text

async def find_product(product):
    code=str(product.get("product_code") or "")
    barcode=_et(product.get("barcode"))
    title=str(product.get("name") or "")
    key=code or barcode or _norm(title)

    cached=_cache.get(key)
    ttl=max(1,settings.hepsiburada_web_cache_minutes)*60
    if cached and time.time()-cached["ts"]<ttl:
        return cached["data"]

    queries=[]
    if barcode:
        queries += [barcode, "2026"+barcode]
    if title:
        queries.append(title)

    async with httpx.AsyncClient(headers=_HEADERS,timeout=25) as client:
        urls=[]
        if key in _url_map:
            urls.append(_url_map[key])
        for q in queries:
            if len(urls)>=5:break
            search_url=f"{BASE}/ara?q={quote(q)}"
            try:
                sh=await _get(client,search_url)
            except Exception:
                continue
            for u in _candidate_links(sh):
                if u not in urls:urls.append(u)
                if len(urls)>=8:break

        scored=[]
        for u in urls[:8]:
            try:
                ph=await _get(client,u)
                info=_parse_product(ph,u)
            except Exception:
                continue
            score=0
            if barcode and info["barcode"]==barcode:score+=100
            nt,ni=_norm(title),_norm(info["title"])
            if nt and ni:
                if nt==ni:score+=60
                elif nt in ni or ni in nt:score+=35
                # token overlap
                a=set(re.findall(r"[a-z0-9]+",title.lower()))
                b=set(re.findall(r"[a-z0-9]+",info["title"].lower()))
                if a:score+=int(20*len(a&b)/len(a))
            if info["seller_verified"]:score+=40
            if info["price"]>0:score+=5
            scored.append((score,info))

        if not scored:
            data={"ok":False,"matched":False,"error":"Hepsiburada web sitesinde güvenilir ürün sayfası bulunamadı.","product_code":code,"barcode":barcode}
        else:
            scored.sort(key=lambda x:x[0],reverse=True)
            score,info=scored[0]
            # Critical safety: do not trust marketplace price as our price unless seller is verified.
            matched=score>=60
            trusted=matched and info["seller_verified"] and info["price"]>0
            data={
                "ok":True,"matched":matched,"trusted_price":trusted,"score":score,
                "product_code":code,"tsoft_barcode":barcode,"query_title":title,
                **info
            }
            if matched:
                _url_map[key]=info["url"]

        _cache[key]={"ts":time.time(),"data":data}
        return data

async def diagnostics():
    url=f"{BASE}/ara?q=altin"
    try:
        async with httpx.AsyncClient(headers=_HEADERS,timeout=20) as client:
            html=await _get(client,url)
        links=_candidate_links(html)
        return {
            "ok":True,
            "mode":"Web Okuma",
            "http":"Başarılı",
            "search_page_read":True,
            "candidate_links":len(links),
            "message":"Hepsiburada herkese açık web sayfasına erişilebildi. API kullanıcı adı/servis anahtarı kullanılmıyor."
        }
    except Exception as e:
        return {"ok":False,"mode":"Web Okuma","http":"Hata","search_page_read":False,"candidate_links":0,"message":str(e)}
