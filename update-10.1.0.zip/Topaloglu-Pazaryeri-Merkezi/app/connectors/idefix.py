import base64, httpx
from ..config import settings

POOL_URL_TEMPLATE="https://merchantapi.idefix.com/pim/pool/{vendor_id}/list"
INVENTORY_URL_TEMPLATE="https://merchantapi.idefix.com/pim/catalog/{vendor_id}/inventory/list"

def _headers():
    if not all([settings.idefix_vendor_id,settings.idefix_api_key,settings.idefix_api_secret]):
        raise RuntimeError("Idefix API bilgileri eksik.")
    token=base64.b64encode(f"{settings.idefix_api_key}:{settings.idefix_api_secret}".encode()).decode()
    return {"X-API-KEY":token,"Accept":"application/json"}

def _f(v):
    try:return float(str(v or 0).replace(",","."))
    except:return 0.0

def _rows(j):
    if isinstance(j,list): return j
    if not isinstance(j,dict): return []
    rows=j.get("products") or j.get("items") or j.get("content") or j.get("data") or []
    if isinstance(rows,dict):
        rows=rows.get("products") or rows.get("items") or rows.get("content") or []
    return rows if isinstance(rows,list) else []

async def _fetch_pool(client):
    url=POOL_URL_TEMPLATE.format(vendor_id=settings.idefix_vendor_id)
    out=[]; page=1; limit=100
    while True:
        r=await client.get(url,params={"page":page,"limit":limit})
        if r.status_code in (401,403):
            raise RuntimeError(f"Idefix yetkilendirme hatası ({r.status_code}).")
        r.raise_for_status()
        rows=_rows(r.json())
        if not rows: break
        out.extend(rows)
        if len(rows)<limit: break
        page+=1
        if page>500: raise RuntimeError("Idefix pool sayfalama güvenlik sınırı aşıldı.")
    return out

async def _fetch_inventory(client):
    url=INVENTORY_URL_TEMPLATE.format(vendor_id=settings.idefix_vendor_id)
    out=[]; page=1; limit=100
    # Idefix inventory-list dokümanında page/limit zorunlu görünmese de
    # pagination desteği olan hesaplarda çalışır; desteklemeyenlerde ilk çağrı yeterlidir.
    while True:
        r=await client.get(url,params={"page":page,"limit":limit})
        if r.status_code in (400,404,422) and page==1:
            r=await client.get(url)
        if r.status_code in (401,403):
            raise RuntimeError(f"Idefix yetkilendirme hatası ({r.status_code}).")
        r.raise_for_status()
        rows=_rows(r.json())
        if not rows: break
        out.extend(rows)
        # paramsiz fallback veya kısa sayfa ise bitir
        if len(rows)<limit: break
        page+=1
        if page>500: raise RuntimeError("Idefix inventory sayfalama güvenlik sınırı aşıldı.")
    return out

async def fetch_inventory():
    """
    Idefix metadata (title/vendorStockCode/productMainId) pool/list'ten,
    GÜNCEL fiyat ve stok inventory/list'ten alınır.
    İki kaynak yalnız barcode üzerinden birleştirilir; başka varyantın fiyatı taşınmaz.
    """
    if not settings.idefix_enabled:return []
    async with httpx.AsyncClient(timeout=60,headers=_headers()) as client:
        pool=await _fetch_pool(client)
        inventory=await _fetch_inventory(client)

    inv_by_barcode={str(x.get("barcode") or "").strip():x for x in inventory if str(x.get("barcode") or "").strip()}
    out=[]
    seen=set()

    for x in pool:
        barcode=str(x.get("barcode") or "").strip()
        inv=inv_by_barcode.get(barcode,{})
        # Güncel inventory price öncelikli. Bulunamazsa pool price fallback.
        price=_f(inv.get("price")) if inv else _f(x.get("price"))
        stock=_f(inv.get("inventoryQuantity")) if inv else _f(x.get("inventoryQuantity"))
        stock_code=str(x.get("vendorStockCode") or inv.get("stockCode") or x.get("stockCode") or "").strip()
        row={
            "barcode":barcode,
            "stock_code":stock_code,
            "product_main_id":str(x.get("productMainId") or "").strip(),
            "title":str(x.get("title") or "").strip(),
            "price":price,
            "compare_price":_f(inv.get("comparePrice")) if inv else _f(x.get("comparePrice")),
            "stock":stock,
            "commission":_f(x.get("commissionRate")),
            "price_source":"inventory-list" if inv else "pool-list-fallback",
        }
        ident=(row["barcode"],row["stock_code"],row["product_main_id"])
        if ident not in seen:
            seen.add(ident); out.append(row)

    # Pool'da bulunmayan inventory kayıtlarını da kaybetme; fakat title boş kalır.
    pool_barcodes={str(x.get("barcode") or "").strip() for x in pool}
    for inv in inventory:
        barcode=str(inv.get("barcode") or "").strip()
        if not barcode or barcode in pool_barcodes: continue
        out.append({
            "barcode":barcode,
            "stock_code":str(inv.get("stockCode") or "").strip(),
            "product_main_id":"",
            "title":"",
            "price":_f(inv.get("price")),
            "compare_price":_f(inv.get("comparePrice")),
            "stock":_f(inv.get("inventoryQuantity")),
            "commission":0.0,
            "price_source":"inventory-list",
        })
    return out

async def fetch_debug_sample(limit=5):
    if not settings.idefix_enabled: raise RuntimeError("Idefix aktif değil.")
    async with httpx.AsyncClient(timeout=60,headers=_headers()) as client:
        pool=await _fetch_pool(client)
        inventory=await _fetch_inventory(client)
    inv_by_barcode={str(x.get("barcode") or "").strip():x for x in inventory}
    out=[]
    for x in pool[:limit]:
        b=str(x.get("barcode") or "").strip()
        out.append({"pool":x,"inventory":inv_by_barcode.get(b)})
    return out
