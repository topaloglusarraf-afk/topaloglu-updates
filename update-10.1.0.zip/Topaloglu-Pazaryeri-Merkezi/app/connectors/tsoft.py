import httpx
from ..config import settings

def f(v):
    try: return float(str(v or 0).replace(",","."))
    except: return 0.0

async def fetch_products():
    if not settings.tsoft_base_url or not settings.tsoft_token:
        raise RuntimeError("TSOFT_BASE_URL veya TSOFT_TOKEN tanımlı değil.")
    url=f"{settings.tsoft_base_url}/rest1/product/get"
    start=0; limit=settings.tsoft_page_size; out=[]
    async with httpx.AsyncClient(timeout=60) as client:
        while True:
            form={"token":settings.tsoft_token,"start":str(start),"limit":str(limit),
                  "FetchSubProducts":"false","FetchDetails":"false","FetchCatalogData":"false","FetchFilters":"false"}
            r=await client.post(url,data=form)
            r.raise_for_status()
            j=r.json()
            if not j.get("success"): raise RuntimeError(str(j.get("message") or j))
            data=j.get("data") or []
            if isinstance(data,dict): data=[data]
            if not data: break
            for x in data:
                code=str(x.get("ProductCode") or "").strip()
                if not code: continue
                out.append({
                    "product_id":str(x.get("ProductId") or ""),
                    "product_code":code,
                    "supplier_product_code":str(x.get("SupplierProductCode") or "").strip(),
                    "barcode":str(x.get("Barcode") or "").strip(),
                    "name":str(x.get("ProductName") or "").strip(),
                    "category":str(x.get("DefaultCategoryName") or "").strip(),
                    "buying_price":f(x.get("BuyingPrice")),
                    "selling_price":f(x.get("SellingPriceVatIncluded") or x.get("SellingPrice")),
                    "stock":f(x.get("Stock")),
                    "is_active":str(x.get("IsActive","true")).lower()=="true"
                })
            if len(data)<limit: break
            start += limit
    return out
