import httpx
from ..config import settings

async def fetch_all_approved_products():
    if not settings.trendyol_enabled:
        return []
    if not all([settings.trendyol_seller_id,settings.trendyol_api_key,settings.trendyol_api_secret]):
        raise RuntimeError("Trendyol API bilgileri eksik.")

    url=f"https://apigw.trendyol.com/integration/product/sellers/{settings.trendyol_seller_id}/products/approved"
    headers={"User-Agent":settings.trendyol_user_agent,"Accept":"application/json"}
    auth=(settings.trendyol_api_key,settings.trendyol_api_secret)
    out=[]; page=0; size=100; next_token=None; seen=set()

    async with httpx.AsyncClient(timeout=60,auth=auth,headers=headers) as client:
        while True:
            params={"size":size}
            if next_token: params["nextPageToken"]=next_token
            else: params["page"]=page

            r=await client.get(url,params=params)
            if r.status_code in (401,403):
                raise RuntimeError(f"Trendyol yetkilendirme hatası ({r.status_code}).")
            r.raise_for_status()
            j=r.json()
            content=j.get("content") or []
            if not content: break

            for product in content:
                title=str(product.get("title") or "").strip()
                pmid=str(product.get("productMainId") or "").strip()
                for v in product.get("variants") or []:
                    barcode=str(v.get("barcode") or "").strip()
                    stock_code=str(v.get("stockCode") or "").strip()
                    key=(barcode,stock_code,pmid)
                    if key in seen: continue
                    seen.add(key)
                    price=v.get("price") or {}
                    stock=v.get("stock") or {}
                    out.append({
                        "barcode":barcode,
                        "stock_code":stock_code,
                        "product_main_id":pmid,
                        "title":title,
                        "price":float(price.get("salePrice") or 0),
                        "customer_price":float(price.get("priceSeenByCustomer") or price.get("salePrice") or 0),
                        "stock":float(stock.get("quantity") or 0),
                        "commission":float(v.get("commission") or 0),
                        "on_sale":bool(v.get("onSale")),
                        "archived":bool(v.get("archived")),
                        "locked":bool(v.get("locked")),
                    })

            total_pages=int(j.get("totalPages") or 1)
            token=j.get("nextPageToken")
            if next_token:
                if not token or token==next_token: break
                next_token=token
                continue
            page += 1
            if page < total_pages and page*size < 10000:
                continue
            if page < total_pages and token:
                next_token=token
                continue
            break
    return out
