import httpx
from ..config import settings

async def fetch_all_products():
    if not settings.n11_enabled: return []
    if not settings.n11_app_key or not settings.n11_app_secret:
        raise RuntimeError("N11 API bilgileri eksik.")
    url="https://api.n11.com/ms/product-query"
    headers={"appkey":settings.n11_app_key,"appsecret":settings.n11_app_secret,"Accept":"application/json"}
    out=[]; page=0; size=250
    async with httpx.AsyncClient(timeout=60,headers=headers) as client:
        while True:
            r=await client.get(url,params={"page":page,"size":size,"sender":"SELLER"})
            if r.status_code in (401,403): raise RuntimeError(f"N11 yetkilendirme hatası ({r.status_code}).")
            r.raise_for_status()
            j=r.json()
            content=j.get("content") or []
            for x in content:
                out.append({
                    "barcode":str(x.get("barcode") or "").strip(),
                    "stock_code":str(x.get("stockCode") or "").strip(),
                    "product_main_id":str(x.get("productMainId") or "").strip(),
                    "title":str(x.get("title") or "").strip(),
                    "price":float(x.get("salePrice") or 0),
                    "stock":float(x.get("quantity") or 0),
                    "commission":float(x.get("commissionRate") or 0),
                })
            total_pages=int(j.get("totalPages") or 0)
            page+=1
            if not content or (total_pages and page>=total_pages): break
    return out
