import httpx
from ..config import settings

def configured():
    return bool(settings.connectprof_enabled and settings.connectprof_base_url)

def _headers():
    h={"Accept":"application/json"}
    if settings.connectprof_bearer_token:
        h["Authorization"]=f"Bearer {settings.connectprof_bearer_token}"
    if settings.connectprof_api_key:
        h["X-API-KEY"]=settings.connectprof_api_key
    return h

async def _get(path):
    if not configured():
        return {"ok":False,"configured":False,"error":"ConnectProf bağlantısı henüz yapılandırılmadı."}
    if not path:
        return {"ok":False,"configured":True,"error":"Bu servis için endpoint path tanımlanmadı."}
    url=f"{settings.connectprof_base_url}/{path.lstrip('/')}"
    async with httpx.AsyncClient(timeout=45) as client:
        r=await client.get(url,headers=_headers())
        r.raise_for_status()
        try: data=r.json()
        except Exception: data={"text":r.text[:2000]}
        return {"ok":True,"configured":True,"status_code":r.status_code,"data":data}

async def health():
    if not configured():
        return {"ok":False,"configured":False,"state":"Bağlantı Bekliyor","message":"ConnectProf API bilgileri .env içinde henüz tanımlanmadı."}
    if not settings.connectprof_products_path:
        return {"ok":True,"configured":True,"state":"Base URL Hazır","message":"Base URL tanımlı. Ürün endpoint path'i girildiğinde canlı veri testi yapılacak."}
    try:
        r=await _get(settings.connectprof_products_path)
        return {"ok":bool(r.get("ok")),"configured":True,"state":"Bağlı" if r.get("ok") else "Hata","message":"ConnectProf API yanıt veriyor." if r.get("ok") else r.get("error","API hatası")}
    except Exception as e:
        return {"ok":False,"configured":True,"state":"Hata","message":str(e)}

async def products(): return await _get(settings.connectprof_products_path)
async def exports(): return await _get(settings.connectprof_exports_path)
async def orders(): return await _get(settings.connectprof_orders_path)
