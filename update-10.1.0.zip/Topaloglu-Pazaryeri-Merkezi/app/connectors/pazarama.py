import httpx
from ..config import settings

TOKEN_URL="https://isortagimgiris.pazarama.com/connect/token"
APPROVED_URL="https://isortagimapi.pazarama.com/product/products/approved"
PRODUCTS_META_URL="https://isortagimapi.pazarama.com/product/getProducts"
SCOPE="merchantgatewayapi.fullaccess"

def f(v):
    try:return float(str(v or 0).replace(",","."))
    except:return 0.0

def deep_get(obj,*keys):
    wanted={str(k).lower() for k in keys}
    def walk(v):
        if isinstance(v,dict):
            for k,val in v.items():
                if str(k).lower() in wanted and val not in (None,"",[],{}): return val
            for val in v.values():
                z=walk(val)
                if z not in (None,"",[],{}): return z
        elif isinstance(v,list):
            for item in v:
                z=walk(item)
                if z not in (None,"",[],{}): return z
        return None
    return walk(obj)

def find_product_list(j):
    """JSON içinden ürün nesnelerini içeren en güçlü listeyi bul."""
    candidates=[]
    def walk(v):
        if isinstance(v,list):
            if v and all(isinstance(x,dict) for x in v[:min(len(v),5)]):
                score=0
                for x in v[:5]:
                    keys={str(k).lower() for k in x.keys()}
                    score+=len(keys & {"name","displayname","code","groupcode","saleprice","stockcount","barcode","price"})
                candidates.append((score,v))
            for x in v: walk(x)
        elif isinstance(v,dict):
            for x in v.values(): walk(x)
    walk(j)
    if not candidates:return []
    candidates.sort(key=lambda x:(x[0],len(x[1])),reverse=True)
    return candidates[0][1]

async def _token(client):
    if not settings.pazarama_api_key or not settings.pazarama_api_secret:
        raise RuntimeError("Pazarama API Key / API Secret eksik.")
    r=await client.post(TOKEN_URL,data={"grant_type":"client_credentials","scope":SCOPE},
                        auth=(settings.pazarama_api_key,settings.pazarama_api_secret),
                        headers={"Content-Type":"application/x-www-form-urlencoded"})
    if r.status_code in (400,401,403):
        r=await client.post(TOKEN_URL,data={"grant_type":"client_credentials","scope":SCOPE,
                            "client_id":settings.pazarama_api_key,"client_secret":settings.pazarama_api_secret},
                            headers={"Content-Type":"application/x-www-form-urlencoded"})
    r.raise_for_status(); j=r.json()
    token=j.get("access_token") or j.get("accessToken")
    if not token and isinstance(j.get("data"),dict):
        token=j["data"].get("accessToken") or j["data"].get("access_token")
    if not token:
        raise RuntimeError("Pazarama token cevabında accessToken bulunamadı.")
    return token

async def _approved(client,headers):
    out=[]; size=100; cursor=None; seen=set()
    while True:
        params={"Size":size}
        if cursor: params["Cursor"]=cursor
        r=await client.get(APPROVED_URL,headers=headers,params=params)
        r.raise_for_status(); j=r.json(); rows=find_product_list(j)
        if not rows: break
        out.extend(rows)
        nxt=deep_get(j,"nextCursor","cursor","nextPageCursor")
        if len(rows)<size or not nxt: break
        nxt=str(nxt)
        if nxt in seen: break
        seen.add(nxt); cursor=nxt
    return out

async def _metadata(client,headers):
    """Name/DisplayName/Code/GroupCode alanlarını Pazarama ürün servisinden al."""
    out=[]; page=1; size=100
    while True:
        params={"Approved":"true","Size":size,"Page":page}
        r=await client.get(PRODUCTS_META_URL,headers=headers,params=params)
        # Bazı hesaplarda bu eski liste servisi kapalı olabilir; approved feed yine çalışsın.
        if r.status_code in (400,404,405): return out
        r.raise_for_status(); rows=find_product_list(r.json())
        if not rows: break
        out.extend(rows)
        if len(rows)<size: break
        page+=1
        if page>500: break
    return out

def _norm_code(v): return str(v or "").strip().lower()

def _to_bool(v):
    if isinstance(v,bool):
        return v
    if v is None:
        return None
    s=str(v).strip().lower()
    if s in {"true","1","yes","evet","active","aktif","approved","on_sale","onsale","published"}:
        return True
    if s in {"false","0","no","hayir","hayır","inactive","pasif","closed","disabled","rejected","unapproved"}:
        return False
    return None

def _to_row(x):
    stock=f(deep_get(x,"StockCount","stockCount","quantity","Quantity","stock","inventoryQuantity","InventoryQuantity"))
    active_raw=deep_get(
        x,
        "IsActive","isActive","Active","active",
        "IsApproved","isApproved","Approved","approved",
        "IsSaleable","isSaleable","Saleable","saleable",
        "OnSale","onSale","IsOnSale","isOnSale",
        "Status","status"
    )
    active=_to_bool(active_raw)

    return {
        # Pazarama'da Code çoğu hesapta satıcı ürün/varyant kodu olarak gelir.
        "barcode":str(deep_get(x,"Barcode","barcode","EAN","ean","GTIN","gtin","Code") or "").strip(),
        "stock_code":str(deep_get(
            x,
            "Code","code",
            "SellerStockCode","sellerStockCode",
            "StockCode","stockCode",
            "MerchantSku","merchantSku",
            "ProductCode","productCode",
            "GroupCode","groupCode"
        ) or "").strip(),
        "product_main_id":str(deep_get(
            x,
            "GroupCode","groupCode",
            "ProductMainId","productMainId",
            "ProductCode","productCode"
        ) or "").strip(),
        "title":str(deep_get(x,"DisplayName","displayName","Name","name","Title","title","ProductName","productName") or "").strip(),
        "price":f(deep_get(
            x,
            "SalePrice","salePrice",
            "SellingPrice","sellingPrice",
            "Price","price",
            "ListPrice","listPrice"
        )),
        "stock":stock,
        "commission":f(deep_get(x,"CommissionRate","commissionRate","Commission","commission")),
        "active":active,
        "raw_status":str(active_raw or "").strip(),
    }

def _market_key(row):
    # Öncelik gerçek varyant/satıcı kodunda.
    return (
        _norm_code(row.get("stock_code"))
        or _norm_code(row.get("barcode"))
        or _norm_code(row.get("product_main_id"))
    )

def _is_sellable(row):
    """Risk hesabına yalnız gerçekten satılabilir Pazarama kayıtlarını dahil et."""
    # API açıkça pasif diyorsa dışarıda bırak.
    if row.get("active") is False:
        return False
    # Stok bilgisi mevcutsa 0 stok satışa kapalı kabul edilir.
    try:
        if float(row.get("stock") or 0) <= 0:
            return False
    except Exception:
        return False
    # Fiyatsız kayıt da risk hesabına giremez.
    try:
        if float(row.get("price") or 0) <= 0:
            return False
    except Exception:
        return False
    return True

async def fetch_all_products():
    if not settings.pazarama_enabled:
        return []

    async with httpx.AsyncClient(timeout=60) as client:
        token=await _token(client)
        headers={"Authorization":f"Bearer {token}","Accept":"application/json"}
        approved_raw=await _approved(client,headers)
        meta_raw=await _metadata(client,headers)

    approved=[_to_row(x) for x in approved_raw]
    meta=[_to_row(x) for x in meta_raw]

    # Metadata indeksleri: varyant kodu > barkod > ana kod.
    meta_by_stock={}
    meta_by_barcode={}
    meta_by_main={}
    for m in meta:
        if _norm_code(m.get("stock_code")):
            meta_by_stock[_norm_code(m["stock_code"])]=m
        if _norm_code(m.get("barcode")):
            meta_by_barcode[_norm_code(m["barcode"])]=m
        if _norm_code(m.get("product_main_id")):
            meta_by_main.setdefault(_norm_code(m["product_main_id"]),[]).append(m)

    out=[]
    used=set()

    for a in approved:
        # Önce aynı varyant kodu. Ana ürün koduna yalnız tek aday varsa düş.
        m=meta_by_stock.get(_norm_code(a.get("stock_code")))
        if not m:
            m=meta_by_barcode.get(_norm_code(a.get("barcode")))
        if not m:
            main_candidates=meta_by_main.get(_norm_code(a.get("product_main_id")),[])
            if len(main_candidates)==1:
                m=main_candidates[0]

        row=dict(a)
        if m:
            # İsim/kod metadata'dan; fiyat/stokta ise mümkün olduğunda approved feed öncelikli.
            if m.get("title"):
                row["title"]=m["title"]
            if m.get("stock_code"):
                row["stock_code"]=m["stock_code"]
            if m.get("product_main_id"):
                row["product_main_id"]=m["product_main_id"]
            if not row.get("barcode") and m.get("barcode"):
                row["barcode"]=m["barcode"]

            # Approved feed stok/fiyat vermediyse metadata'daki değeri tamamlayıcı kullan.
            if float(row.get("price") or 0) <= 0 and float(m.get("price") or 0) > 0:
                row["price"]=m["price"]
            if float(row.get("stock") or 0) <= 0 and float(m.get("stock") or 0) > 0:
                row["stock"]=m["stock"]

            # İki kayıttan biri açıkça pasifse pasif kabul et.
            if a.get("active") is False or m.get("active") is False:
                row["active"]=False
            elif a.get("active") is True or m.get("active") is True:
                row["active"]=True

            used.add(_market_key(m))

        # v8.12: stok 0 / pasif kayıtlar da görünür tutulur.
        if row.get("stock_code") or row.get("barcode") or row.get("title"):
            out.append(row)

    # v8.12: metadata'daki stok 0 / pasif ürünleri de görünür tut.
    for m in meta:
        key=_market_key(m)
        if key and key not in used and (m.get("stock_code") or m.get("barcode") or m.get("title")):
            out.append(m)

    # Aynı varyant kodu birden fazla kez geldiyse fiyat/stok açısından en güncel/uygun kaydı tekilleştir.
    dedup={}
    for r in out:
        key=_market_key(r) or (
            _norm_code(r.get("title")),
            float(r.get("price") or 0),
        )
        if key not in dedup:
            dedup[key]=r
        else:
            old=dedup[key]
            # Daha yüksek stok bilgisi olan kaydı tercih et; eşitse mevcut kalır.
            if float(r.get("stock") or 0) > float(old.get("stock") or 0):
                dedup[key]=r

    return list(dedup.values())

async def fetch_debug_sample(limit=5):
    rows=await fetch_all_products()
    return rows[:limit]
