COMMISSION_RATES = {
    "Trendyol": {"Gram Altın":10.0,"Sarrafiye":10.0,"22 Ayar Bilezik":10.0,"Takılar-14 Ayar":24.5},
    "Hepsiburada": {"Gram Altın":7.2,"Sarrafiye":7.2,"22 Ayar Bilezik":7.2,"Takılar-14 Ayar":11.32},
    "N11": {"Gram Altın":7.2,"Sarrafiye":7.2,"22 Ayar Bilezik":8.1,"Takılar-14 Ayar":24.0},
    "Idefix": {"Gram Altın":6.0,"Sarrafiye":6.0,"22 Ayar Bilezik":6.0,"Takılar-14 Ayar":6.0},
    "Pazarama": {"Gram Altın":9.2,"Sarrafiye":9.2,"22 Ayar Bilezik":9.2,"Takılar-14 Ayar":22.0,"Takılar-8 Ayar":22.0},
}
GROUPS = ["İncelenecek","Gram Altın","Sarrafiye","22 Ayar Bilezik","Takılar-14 Ayar"]

def fallback_commission(marketplace, group):
    if group == "İncelenecek":
        return None
    return COMMISSION_RATES.get(marketplace, {}).get(group)

def expected_price(tsoft_price: float, commission_percent: float) -> float:
    r=commission_percent/100.0
    if not 0 <= r < 1: raise ValueError("Geçersiz komisyon")
    return round(float(tsoft_price)/(1-r),2)
