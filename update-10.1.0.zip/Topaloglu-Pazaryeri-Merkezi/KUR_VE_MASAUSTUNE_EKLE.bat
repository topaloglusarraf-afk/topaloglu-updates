@echo off
chcp 65001 >nul
setlocal
set "TARGET=%LOCALAPPDATA%\Topaloglu\PazaryeriMerkezi"
echo.
echo ================================================
echo   TOPALOGLU PAZARYERI MERKEZI - KALICI KURULUM
echo ================================================
echo.
echo Kurulum klasoru:
echo %TARGET%
echo.

if not exist "%TARGET%" mkdir "%TARGET%"

rem Existing user env/db are never overwritten.
if exist "%TARGET%\.env" copy /Y "%TARGET%\.env" "%TEMP%\topaloglu_env_backup" >nul
if exist "%TARGET%\topaloglu.db" copy /Y "%TARGET%\topaloglu.db" "%TEMP%\topaloglu_db_backup" >nul

robocopy "%~dp0" "%TARGET%" /E /NFL /NDL /NJH /NJS /NP /XF ".env" "topaloglu.db" "KUR_VE_MASAUSTUNE_EKLE.bat" >nul

if exist "%TEMP%\topaloglu_env_backup" (
  copy /Y "%TEMP%\topaloglu_env_backup" "%TARGET%\.env" >nul
  del "%TEMP%\topaloglu_env_backup" >nul 2>&1
) else (
  if exist "%~dp0.env" copy /Y "%~dp0.env" "%TARGET%\.env" >nul
)

if exist "%TEMP%\topaloglu_db_backup" (
  copy /Y "%TEMP%\topaloglu_db_backup" "%TARGET%\topaloglu.db" >nul
  del "%TEMP%\topaloglu_db_backup" >nul 2>&1
) else (
  if exist "%~dp0topaloglu.db" copy /Y "%~dp0topaloglu.db" "%TARGET%\topaloglu.db" >nul
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Topaloglu Pazaryeri Merkezi.lnk'); $s.TargetPath='%TARGET%\BASLAT.bat'; $s.WorkingDirectory='%TARGET%'; $s.IconLocation='%SystemRoot%\System32\SHELL32.dll,220'; $s.Save()"

echo.
echo Kurulum tamamlandi.
echo Bundan sonra masaustundeki "Topaloglu Pazaryeri Merkezi" kisayolunu kullanin.
echo .env ve veritabaniniz bu klasorde sabit kalacak.
echo.
start "" "%TARGET%\BASLAT.bat"
timeout /t 3 >nul
exit /b 0
